# NovaMart Demo — Knowledge Base for SupportForge

A complete, fictional e-commerce customer support knowledge base designed for testing the SupportForge AI chat platform. These documents simulate a real-world knowledge base for "NovaMart," a premium online marketplace.

## Documents

| # | File | Content | Topics Covered |
|---|---|---|---|
| 01 | `01-shipping-and-delivery-policy.md` | Shipping methods, tracking, delivery issues, restrictions | Standard/Express/Overnight/International shipping, tracking statuses, delivery problems, holiday schedule, signature requirements, military shipping, address changes |
| 02 | `02-returns-and-refunds-policy.md` | Return windows, eligibility, refund processing, exchanges | Return windows by category, how to initiate returns, refund methods and timelines, partial refunds, defective items, late returns |
| 03 | `03-account-and-billing-faq.md` | Account management, payment methods, billing, rewards | Account creation, password reset, profile management, accepted payments, billing charges, pre-authorization holds, invoices, promo codes, price matching |
| 04 | `04-product-warranty-and-support.md` | Warranty coverage, NovaCare plans, troubleshooting | Standard warranty by category, NovaCare tiers, claim process, resolution types, detailed troubleshooting guides, repair services, software support |
| 05 | `05-privacy-policy.md` | Data collection, sharing, GDPR/CCPA rights, cookies, security | Data we collect, how it's used, third-party sharing, user rights, cookie types, data retention, children's privacy |
| 06 | `06-order-management-and-cancellations.md` | Order lifecycle, modifications, cancellations, subscriptions | Placing orders, tracking, modifying orders, cancellation policy, pre-orders, backorders, auto-reorder subscriptions, gift orders |
| 07 | `07-product-categories-and-sizing.md` | Product catalog, sizing charts, product conditions | All product categories, clothing sizing (men's/women's/kids'), shoe sizing, sizing tips, product condition guide, certified refurbished |
| 08 | `08-loyalty-and-membership.md` | Rewards program, Premium membership, referrals, gift cards | Points earning/redemption, membership tiers, NovaMart Premium plans, student/family options, referral program, gift cards, store credit |
| 09 | `09-contact-and-store-policies.md` | Contact methods, store info, policies | Phone menu, email directory, live chat, social media, store locations, trade-in program, accessibility, sustainability, price match, product authenticity |

## Setup

### Quick Setup (API already running)
```bash
# 1. Create tenant via Python (requires running from supportforge-api dir)
cd ../supportforge-api
.venv/bin/python -c "
import asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from app.config import get_settings
from app.infrastructure.database.repositories.tenant_repo import SQLTenantRepository
from app.domain.models.tenant import Tenant
async def main():
    settings = get_settings()
    engine = create_async_engine(settings.computed_database_url)
    sf = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with sf() as session:
        repo = SQLTenantRepository(session)
        existing = await repo.get_by_slug('novamart')
        if existing:
            print(f'Tenant exists: {existing.id}')
        else:
            t = Tenant(name='NovaMart', slug='novamart')
            created = await repo.create(t)
            await session.commit()
            print(f'Created: {created.id}')
    await engine.dispose()
asyncio.run(main())
"

# 2. Register admin user (replace TENANT_ID with the ID from step 1)
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@novamart.com","password":"NovaMart2025!@#","tenant_id":"TENANT_ID","role":"admin"}'

# 3. Login
TOKEN=$(curl -s -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@novamart.com","password":"NovaMart2025!@#","tenant_id":"TENANT_ID"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

# 4. Upload all docs
for doc in *.md; do
  [ "$doc" = "README.md" ] && continue
  curl -X POST http://localhost:8000/api/v1/documents/upload \
    -H "Authorization: Bearer $TOKEN" \
    -F "file=@$doc"
done
```

### Login Credentials
```
Admin (full access — Chat, Admin, Analytics, Review Queue):
  Email:     admin@novamart.com
  Password:  NovaMart2025!@#
  Tenant ID: 470d2f06-fa9e-4ac7-b679-49610418b85b
  Role:      admin

Viewer (Chat only — no admin panels):
  Email:     user@novamart.com
  Password:  NovaMart2025!@#
  Tenant ID: 470d2f06-fa9e-4ac7-b679-49610418b85b
  Role:      viewer

Superadmin (Platform management — cross-tenant access):
  Email:     super@platform.dev
  Password:  SuperAdmin2025!@#
  Tenant ID: 470d2f06-fa9e-4ac7-b679-49610418b85b
  Role:      superadmin
```

## Sample Questions to Test

Once documents are ingested (status = `ready`), try asking the chatbot:

### Shipping & Delivery
- "What is the cost for express shipping?"
- "How do I track my order?"
- "Do you ship to APO/FPO addresses?"
- "What happens if my package is marked delivered but I didn't get it?"
- "Is same-day delivery available?"
- "When should I order for Christmas delivery?"

### Returns & Refunds
- "What is the return policy for electronics?"
- "Can I return a gift?"
- "How long do refunds take to process?"
- "What if I received a damaged item?"
- "Can I return something without the original packaging?"
- "What if I'm past the return window?"

### Account & Billing
- "How do I reset my password?"
- "What payment methods do you accept?"
- "Why was I charged twice for my order?"
- "How do I apply a promo code?"
- "How do I delete my account?"
- "Do you offer price matching?"

### Product Support
- "What does the standard warranty cover?"
- "How do I file a NovaCare claim?"
- "My device won't turn on — what should I do?"
- "How do I get replacement parts for furniture?"
- "Do you offer out-of-warranty repairs?"

### Orders & Management
- "Can I cancel my order?"
- "How do I change my shipping address after ordering?"
- "What is auto-reorder and how does it work?"
- "Can I modify an order after it's placed?"
- "How do pre-orders work?"

### Membership & Rewards
- "How do I earn rewards points?"
- "What are the membership tiers?"
- "What is NovaMart Premium?"
- "How do I refer a friend?"
- "Do my points expire?"
- "How do I check my gift card balance?"

### Product Categories & Sizing
- "What size should I order if I'm between sizes?"
- "How do I measure my shoe size?"
- "What does Certified Refurbished mean?"
- "Do you sell smart home devices?"

### Privacy & Policies
- "What is your privacy policy?"
- "What data do you collect about me?"
- "How do I download my personal data?"
- "Do you sell my information to third parties?"
- "What are my GDPR rights?"

### Contact & Store
- "How do I contact customer support?"
- "What are your customer support hours?"
- "Do you have retail stores?"
- "How does the trade-in program work?"
- "Is your website accessible for screen readers?"
