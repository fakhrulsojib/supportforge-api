# Shipping & Delivery Policy

**Last Updated:** January 2025  
**Company:** NovaMart — Your Premium Online Marketplace

---

## Shipping Methods & Delivery Times

### Standard Shipping
- **Cost:** Free on orders over $50, otherwise $5.99
- **Delivery Time:** 5–7 business days
- **Carrier:** USPS, UPS Ground
- **Tracking:** Included, sent via email within 24 hours of shipment

### Express Shipping
- **Cost:** $12.99
- **Delivery Time:** 2–3 business days
- **Carrier:** UPS 2-Day, FedEx Express
- **Tracking:** Real-time tracking with SMS and email notifications

### Overnight Shipping
- **Cost:** $24.99
- **Delivery Time:** Next business day (orders placed before 2:00 PM EST)
- **Carrier:** FedEx Priority Overnight
- **Tracking:** Real-time tracking with delivery confirmation
- **Note:** Not available for P.O. boxes or APO/FPO addresses

### International Shipping
- **Cost:** Calculated at checkout based on destination and weight
- **Delivery Time:** 10–21 business days
- **Carrier:** DHL International, UPS Worldwide
- **Customs:** Customer is responsible for all customs duties, taxes, and import fees
- **Restricted Countries:** We do not ship to sanctioned countries. See full list at novamart.com/restricted

---

## Order Processing

- Orders are processed within 1–2 business days (Monday–Friday)
- Orders placed on weekends or holidays are processed the next business day
- You will receive a confirmation email immediately after placing your order
- A shipping notification with tracking number is sent when your order ships
- Business days exclude weekends and federal holidays

### Cut-off Times
| Shipping Method | Cut-off Time (EST) |
|---|---|
| Standard | 11:59 PM |
| Express | 2:00 PM |
| Overnight | 2:00 PM |

---

## Tracking Your Order

1. **Email:** Check your shipping confirmation email for a tracking link
2. **Account Dashboard:** Log in to your NovaMart account → "My Orders" → click the order number
3. **Direct Tracking:** Visit the carrier's website (USPS.com, UPS.com, FedEx.com) and enter your tracking number
4. **Customer Support:** Contact us at support@novamart.com or call 1-800-NOVA-MART (1-800-668-2627)

### Common Tracking Statuses
- **Label Created:** Shipping label has been printed; package not yet picked up
- **In Transit:** Package is on its way to you
- **Out for Delivery:** Package will arrive today
- **Delivered:** Package has been delivered to the address on file
- **Exception:** There's an issue with delivery — contact support

---

## Delivery Issues

### Package Not Received
If your tracking shows "Delivered" but you haven't received your package:
1. Check with neighbors and building management
2. Look in all delivery areas (porch, mailbox, garage, side door)
3. Wait 24 hours — sometimes tracking updates before actual delivery
4. Contact the carrier directly with your tracking number
5. If still unresolved after 48 hours, contact NovaMart support for a replacement or refund

### Damaged Package
- Take photos of the damaged packaging and items before discarding anything
- Contact support within 7 days of delivery
- We will send a replacement at no additional cost
- You may be asked to return the damaged item (we provide a prepaid return label)

### Wrong Item Received
- Contact support within 14 days of delivery
- We will send the correct item immediately
- A prepaid return label will be provided for the wrong item
- You do not need to wait for the return to receive the correct item

---

## Shipping Restrictions

### Items That Cannot Be Shipped
- Hazardous materials (flammables, explosives, chemicals)
- Perishable goods (unless specified on the product page)
- Live animals
- Items exceeding 150 lbs or 108 inches in length

### Address Requirements
- We ship to residential and commercial addresses within the United States
- P.O. Box delivery is available for Standard Shipping only
- APO/FPO/DPO addresses are supported with Standard Shipping (delivery may take 2–4 additional weeks)
- We do not ship to freight forwarding addresses

---

## Holiday Shipping Schedule

During peak seasons (November–December), please allow an additional 2–3 business days for delivery. We recommend:
- **Order by December 15** for Standard Shipping delivery before Christmas
- **Order by December 20** for Express Shipping delivery before Christmas
- **Order by December 22** for Overnight Shipping delivery before Christmas

Other peak periods with potential delays:
- **Valentine's Day (Feb 14):** Order by Feb 10 for Standard
- **Mother's Day (May):** Order by the Monday before for Express
- **Back-to-School (August):** Allow an extra 1–2 business days
- **Black Friday / Cyber Monday:** Allow an extra 2–4 business days for Standard

---

## Signature & Delivery Requirements

### When Signature Is Required
- All orders over $200 require a signature at delivery
- All Overnight shipments require a signature
- Electronics orders (laptops, phones, tablets) always require a signature regardless of value
- You can waive the signature requirement by logging in → "My Orders" → "Delivery Preferences" (you assume liability)

### Delivery Instructions
- Add delivery notes during checkout or in "My Orders" → "Delivery Preferences"
- Examples: "Leave at back door," "Ring doorbell," "Deliver to office on 2nd floor"
- Carriers make best efforts to follow instructions but cannot guarantee
- For apartment/condo buildings: include unit number, access codes, and building manager contact if applicable

### What Happens If You're Not Home
- **Standard/Express:** Carrier leaves the package at the door (unless signature required)
- **Signature required:** Carrier attempts delivery up to 3 times, then the package is held at the nearest carrier facility for 7 days
- **After 7 days:** Package is returned to NovaMart — we'll reship for free or issue a refund

---

## Shipping to Multiple Addresses

- Currently, each order can ship to **one address only**
- To ship to multiple addresses, place separate orders for each destination
- All separate orders qualify independently for free shipping ($50+ threshold)
- **Gift orders:** You can ship directly to the recipient — check "This is a gift" at checkout to hide prices

---

## Military & Government Shipping

- We support shipping to **APO, FPO, and DPO addresses** via Standard Shipping
- Delivery time: 7–21 business days depending on the destination
- Express and Overnight shipping are **not available** for military addresses
- All customs forms are handled automatically — no extra steps required
- Active military personnel receive a **10% discount** with valid military ID (verify at novamart.com/military)

---

## Change of Address After Ordering

- **Before shipment:** You can update the shipping address from "My Orders" → "Modify Order"
- **After shipment:** Contact support immediately — we may be able to request a carrier redirect (additional fee may apply, typically $5–$15)
- **Carrier redirect not possible:** Wait for the package to be returned, then we'll reship to the correct address for free
- **Note:** Address changes may delay delivery by 1–2 business days

---

## Frequently Asked Questions

**Q: Why does my tracking show "Label Created" for more than 24 hours?**
A: This means the shipping label has been printed but the carrier hasn't scanned the package yet. This is common during peak periods. If it hasn't updated after 3 business days, contact support.

**Q: Can I pick up my order at a carrier location instead of home delivery?**
A: Yes! UPS and FedEx allow you to redirect your package to a local pickup point. Use the tracking number on the carrier's website to set up "Hold at Location."

**Q: Do you offer same-day delivery?**
A: Same-day delivery is available in select metro areas (New York, Los Angeles, Chicago, Austin, Seattle) for orders placed before 10:00 AM local time. Cost: $14.99. Check availability at checkout.

**Q: My order shipped in multiple packages. Is that normal?**
A: Yes. Items may ship from different warehouses or require separate packaging for protection. Each package has its own tracking number, visible in "My Orders."

**Q: Can I combine multiple orders into one shipment?**
A: Unfortunately, we cannot combine orders after they've been placed. Each order is processed independently.

**Q: What is "NovaMart Fulfilled" vs. "Sold by NovaMart"?**
A: "Sold by NovaMart" means NovaMart is the seller and ships the item. "NovaMart Fulfilled" means a third-party seller's item is stored in and shipped from a NovaMart warehouse with the same shipping speeds and reliability. Both are covered by NovaMart's return policy.

---

## Contact Information

- **Email:** support@novamart.com
- **Phone:** 1-800-NOVA-MART (1-800-668-2627)
- **Hours:** Monday–Friday, 8:00 AM – 8:00 PM EST; Saturday, 9:00 AM – 5:00 PM EST
- **Live Chat:** Available at novamart.com during business hours
- **Track your order:** novamart.com/track or "My Orders" in your account
