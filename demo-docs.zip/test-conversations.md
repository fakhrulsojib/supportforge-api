# NovaMart — Customer Conversation Test Sets

Natural conversation sets simulating real NovaMart customers contacting support. Each set represents a single customer session with a specific scenario. Questions range from directly answerable from docs to natural follow-ups that test the AI's ability to stay on-topic and handle ambiguity.

---

## Set 1: Frustrated Customer — Late Holiday Delivery

> **Scenario:** Customer ordered gifts in December, package is delayed, they're panicking.

1. "I ordered something on December 18th with express shipping and it still hasn't arrived. It's the 23rd now!"
2. "The tracking says 'In Transit' — what does that even mean? When will it actually get here?"
3. "I specifically chose express so it'd arrive before Christmas. Can you guarantee it'll be here tomorrow?"
4. "If it doesn't arrive by Christmas, can I get a full refund including the shipping cost?"
5. "Can you upgrade my shipping to overnight at this point? I'll pay the difference."
6. "What if I just go buy the same thing at Best Buy — will you price match and refund my order?"
7. "Your website said 2-3 business days for express. It's been 5 days. That's false advertising."
8. "Can I redirect the package to a FedEx pickup location so I can grab it on my way to dinner?"
9. "I want to speak to a manager. This is unacceptable for a company that calls itself 'premium'."
10. "If this happens again next year, what's the latest I can order and still get it by Christmas?"
11. "Do you offer any kind of compensation for late deliveries? Store credit, anything?"
12. "I'm a Gold member — doesn't that give me any priority on shipping?"

---

## Set 2: New Customer — First Purchase Confusion

> **Scenario:** Someone who just created an account and is trying to place their first order.

1. "Hi, I just signed up. Do I need to verify my email or anything before I can order?"
2. "What payment methods do you accept? Can I use Apple Pay?"
3. "I see something about rewards points — do I automatically earn those or do I have to sign up separately?"
4. "How many points would I earn if I buy a $200 laptop?"
5. "I got a referral link from my friend. Where do I enter that?"
6. "Does the $10 off from the referral stack with the promo code I found online?"
7. "I'm checking out and it says 'free shipping on orders over $50' — my cart is $48. If I add a phone case would that push me over?"
8. "What's the difference between Standard and Express shipping? Is Express worth it?"
9. "I want to ship this to my mom in a different state. Can I use a different shipping address than my billing address?"
10. "Should I get NovaCare for the laptop? Is it worth the $79.99?"
11. "Actually, can I add NovaCare later if I decide I want it? Or do I have to buy it now?"
12. "One more thing — if the laptop doesn't work out, what's the return policy?"
13. "And how long until I get the rewards points from this purchase?"
14. "I placed the order! But I didn't get a confirmation email. Is that normal?"

---

## Set 3: Return Nightmare — Wrong Item Then Damaged Replacement

> **Scenario:** Customer received the wrong item, got a replacement that arrived damaged.

1. "I ordered a blue Nike jacket in size L but received a red Adidas hoodie in size M. This is completely wrong."
2. "Do I have to send the wrong item back before you ship the right one?"
3. "Who pays for return shipping on the wrong item? I shouldn't have to pay for your mistake."
4. "OK so you shipped the replacement via Express. It arrived today but the box was crushed and the jacket has a crease mark on the back."
5. "This is the second time I've had a problem with this order. I want a full refund now, not another replacement."
6. "Can I get the refund as store credit with that 10% bonus you offer? So at least I get something extra for the trouble."
7. "How long will the refund take to show up on my Visa?"
8. "Do I need to return the damaged replacement too? I really don't want to go to UPS again."
9. "My order was $75. With the 10% store credit bonus that would be $82.50, right?"
10. "Can I use that store credit immediately or is there a waiting period?"
11. "Will I still get rewards points for this order even though I'm getting a refund?"
12. "I want to file a formal complaint. How do I do that?"

---

## Set 4: Premium Membership Deep Dive

> **Scenario:** A Silver-tier customer considering upgrading to Premium.

1. "I spend about $2,000 a year on NovaMart. I'm currently Silver. Should I get Premium?"
2. "Wait, with $2,000 annual spend, shouldn't I be Gold already? The threshold is $1,500 right?"
3. "OK so I'm Gold then. What exactly does Gold give me that Silver doesn't?"
4. "If I also get Premium, do the benefits stack? Like would I get 4x points?"
5. "How does that math work? Gold is 2x and Premium is 2x, so is it 2+2=4x or 2×2=4x?"
6. "And what about the return window? Gold gives 45 days but Premium gives 60. Do I get 105 days?"
7. "Is the $99/year plan worth it if I already have Gold-level free Express shipping?"
8. "What's this 'Premium Price' badge I see on some products? How much do you typically save?"
9. "Can my wife use my Premium benefits too? We live together."
10. "What about the student plan — my daughter is in college. Can she get the $49 plan under my account?"
11. "If I sign up today, when do benefits kick in? My next order ships tomorrow."
12. "Can I try it for a month at $9.99 and then switch to annual if I like it?"
13. "What happens to my Gold tier benefits if I cancel Premium later?"
14. "One more thing — does Premium give me anything for NovaCare warranties?"

---

## Set 5: Warranty Claim — Laptop Issues

> **Scenario:** Customer's 8-month-old laptop is having problems, exploring warranty options.

1. "My laptop keeps shutting down randomly. I bought it about 8 months ago."
2. "I haven't tried anything yet. What should I do before filing a warranty claim?"
3. "OK I tried the hard reset and clearing the cache. It still shuts down after about 20 minutes."
4. "Could it be a battery issue? The battery seems to drain really fast too."
5. "How do I check the battery health?"
6. "It says battery health is at 74%. Is that covered under warranty?"
7. "I don't have NovaCare. Can I still add it now or is it too late? I bought it 8 months ago."
8. "So I'm stuck with just the standard warranty then. What happens if I file a claim?"
9. "How long does the repair take? I use this laptop for work and can't be without it for two weeks."
10. "Do you offer loaner devices while mine is being repaired?"
11. "What if you can't fix it? Would I get a replacement or a refund?"
12. "The laptop cost $899. Would I get the full $899 back or some depreciated amount?"
13. "If I get a replacement, is it a brand new one or a refurbished one?"
14. "What warranty does the replacement come with? Does it restart the clock?"
15. "OK let's file the claim. What information do you need from me?"
16. "Where do I find my product serial number?"

---

## Set 6: International Customer — Shipping & Customs

> **Scenario:** Customer in Canada trying to order from NovaMart.

1. "Do you ship to Canada?"
2. "How much does international shipping cost for a package around 5 pounds?"
3. "How long will it take to get to Toronto?"
4. "Am I going to get hit with customs duties? How much would that be?"
5. "Who pays the customs fees — me or NovaMart?"
6. "Can I use a Canadian credit card? I'm worried about currency conversion."
7. "Do you show prices in Canadian dollars or only USD?"
8. "I have a NovaMart gift card my friend gave me. Can I use it from Canada?"
9. "What if I need to return the item? Do you cover international return shipping?"
10. "I'm a Premium member. Does my free Express shipping work for international orders?"
11. "That's disappointing. So what's the point of Premium for international customers?"
12. "Are there any items that can't be shipped internationally? I want to order a power tool."
13. "What about the warranty — does it still apply if I'm in Canada?"
14. "If something breaks, do I have to ship it back to the US for repair?"

---

## Set 7: Privacy-Conscious Customer

> **Scenario:** A customer concerned about data privacy, possibly preparing a GDPR request.

1. "What data do you collect about me when I browse your website?"
2. "I noticed you use Google Analytics. Can I opt out of that tracking?"
3. "Do you sell my personal data to advertisers?"
4. "I want to download all the data you have on me. How do I do that?"
5. "How long will it take to get my data export?"
6. "What format will the data be in? Is it machine-readable?"
7. "I see you share data with shipping carriers. Can I prevent that and still get my orders?"
8. "What happens to my chat history with your support bot? Is that stored?"
9. "How long do you keep my support tickets after they're resolved?"
10. "I want to delete my account entirely. But I have an open order. Can I still delete it?"
11. "After I delete my account, how long do you actually keep my data?"
12. "You said 7 years for order history. That seems like a long time. Why so long?"
13. "What about my saved payment info? Is that deleted immediately?"
14. "Do you comply with GDPR even though you're a US company?"
15. "If there's ever a data breach, how would you notify me?"
16. "Can my 16-year-old daughter create her own account?"

---

## Set 8: Bargain Hunter — Maximizing Discounts

> **Scenario:** Customer trying to stack every possible discount, promo, and reward.

1. "I have a promo code, a gift card, and rewards points. Can I use all three on the same order?"
2. "Can I use two promo codes on one order?"
3. "I found this item cheaper on Amazon. Do you price match?"
4. "The competitor price is on Amazon Marketplace — a third-party seller. Does that count?"
5. "What if the item drops in price on YOUR site after I buy it? Can I get the difference back?"
6. "How long after purchase does the price drop protection last?"
7. "I'm a Premium member — does the price drop refund happen automatically for me?"
8. "Can I use my military discount AND a promo code at the same time?"
9. "My order is $49.50. Is there a cheap item I can add to hit the $50 free shipping threshold?"
10. "If I set up auto-reorder, I get 10% off right? Does that stack with a promo code?"
11. "I'm about to hit Platinum tier — I've spent $4,800 this year. If I make this $250 purchase, when do the Platinum benefits kick in?"
12. "What's the quarterly coupon that Silver members get? How do I find it?"
13. "My birthday is next week. Will I get birthday bonus points? How many?"
14. "If I buy a $500 gift card, do I earn points on that?"
15. "Can I buy a gift card with store credit?"

---

## Set 9: Furniture Purchase — Delivery & Assembly Concerns

> **Scenario:** Customer ordering a large sectional sofa and a desk.

1. "I'm looking at a sectional sofa that weighs 140 lbs. Can you ship that?"
2. "What about the matching ottoman that's 45 lbs — can those ship together?"
3. "How much would shipping cost for the sofa? It's over $50 so would it be free?"
4. "Does the sofa require assembly? I'm not handy at all."
5. "Do you offer professional assembly services?"
6. "How much does TaskRabbit assembly cost through you guys?"
7. "If parts are missing from the box, how quickly can you send replacements?"
8. "What if I assemble it and realize it's too big for my room? Can I return it?"
9. "What's the restocking fee for furniture? That seems steep."
10. "Wait — if I return it because it's defective, do I still pay the restocking fee?"
11. "What's the warranty on furniture? If a leg breaks after 6 months, am I covered?"
12. "I also want a standing desk. Do your desks come with a warranty on the motor?"
13. "Can I order the sofa and desk together or do they have to be separate orders?"
14. "Will they arrive in the same delivery? Or will I get multiple packages on different days?"
15. "I live in a third-floor walkup apartment. Will the driver carry it upstairs?"
16. "Do I need to be home to sign for it? I work during the day."

---

## Set 10: Gift Giving — Holiday Shopping

> **Scenario:** Customer buying multiple gifts for family members.

1. "I need to buy gifts for 4 different people and ship to 4 different addresses. Can I do that in one order?"
2. "OK so I need separate orders. Will each one qualify for free shipping independently?"
3. "Can I add gift wrapping? How much does it cost?"
4. "I'm a Gold member — does that mean gift wrapping is free for me?"
5. "Can I include a personalized message with the gift?"
6. "Will the receipt show the prices? I don't want the recipient to see how much I spent."
7. "What if the person doesn't like the gift? Can they return it without telling me?"
8. "How would the refund work for a gift return — does the money go back to me or to them?"
9. "I want to buy a gift card for someone. What denominations do you offer?"
10. "Can I send a digital gift card that arrives on Christmas morning at a specific time?"
11. "What if the gift card email goes to their spam folder? Is there a backup?"
12. "Do NovaMart gift cards expire?"
13. "Can the recipient use the gift card with a promo code?"
14. "I'm also thinking about getting my nephew a gaming console. That's an electronics item — what's the return window if he already has one?"
15. "Can I buy NovaCare warranty as a gift? Like buy it for someone else's product?"

---

## Set 11: Subscription & Auto-Reorder Management

> **Scenario:** Customer managing their auto-reorder subscriptions and having billing issues.

1. "I set up auto-reorder for dog food 6 weeks ago but I still have a full bag. Can I skip the next delivery?"
2. "How many days before the shipment do I need to skip it?"
3. "Can I change the delivery frequency? I want to go from every 4 weeks to every 6 weeks."
4. "I want to switch from the chicken flavor to the salmon flavor. Can I do that without canceling?"
5. "What's the 10% auto-reorder discount applied to? The original price or the current price?"
6. "My card expired and the auto-reorder payment failed. What happens now?"
7. "It says my subscription was 'paused' — how do I resume it?"
8. "Can I pause it intentionally? I'm going on vacation for 2 months."
9. "When I come back and unpause, will I still get the 10% discount?"
10. "How many different products can I have on auto-reorder at the same time?"
11. "Can I set up auto-reorder for electronics, like getting a new phone case every year?"
12. "If I return an auto-reorder item, does the subscription keep going?"
13. "I want to cancel one subscription but keep the others. How do I do that?"
14. "If I cancel, will I lose the 10% discount if I resubscribe later?"

---

## Set 12: Accessibility & Special Needs

> **Scenario:** Customer with visual impairment navigating the website and ordering.

1. "I use a screen reader. Is your website accessible?"
2. "I'm having trouble with the checkout page. The 'Place Order' button doesn't seem to have a label."
3. "Do you have a phone number I can call to place an order? I find the website difficult."
4. "Is there an extra charge for placing an order over the phone?"
5. "Do you have a TTY number for deaf customers? My partner is deaf and wants to order."
6. "What about video relay service? Can my partner use that to call you?"
7. "Your product images don't always have alt text. Is that something you're working on?"
8. "Can I get large-print instructions included with my order?"
9. "Are your retail stores wheelchair accessible?"
10. "Do you allow service animals in your stores?"
11. "I noticed some of your product videos don't have captions. Will those be added?"
12. "Who should I contact to report accessibility issues I find on the website?"
13. "How quickly do you respond to accessibility feedback?"

---

## Set 13: Trade-In & Upgrade Cycle

> **Scenario:** Customer wanting to trade in old devices and buy new ones.

1. "I have an old iPhone 13 I want to trade in. How does that work?"
2. "How do I know how much my phone is worth?"
3. "The screen has a small crack in the corner. Does that affect the trade-in value?"
4. "Do I have to mail it in or can I bring it to a store?"
5. "How long does it take to get the store credit after you receive my phone?"
6. "Can I use the trade-in credit toward a new iPhone 15 immediately, or do I have to wait?"
7. "Do I need to factory reset my phone before sending it in?"
8. "What happens to my data if I forget to wipe it?"
9. "I also have an old iPad Air 4th gen. Can I trade in multiple devices at once?"
10. "Can I trade in a device I didn't buy from NovaMart originally?"
11. "What about an old PlayStation 4? Do you accept that for trade-in?"
12. "Is the trade-in credit regular store credit? Does it ever expire?"
13. "Can I combine trade-in credit with a promo code and rewards points on one order?"
14. "If the trade-in value estimate online is $250, is that guaranteed or could it be lower?"

---

## Set 14: Smart Home Setup Problems

> **Scenario:** Customer bought a smart home bundle and can't get devices connected.

1. "I bought a NovaMart smart plug and a smart bulb but neither will connect to my WiFi."
2. "My router broadcasts both 2.4GHz and 5GHz on the same network name. Could that be the problem?"
3. "How do I separate the bands on my router? Is that something you can help with?"
4. "OK I connected the smart plug on 2.4GHz and it works now. But the bulb still won't pair."
5. "I downloaded the NovaMart Home app but it keeps crashing on my Android phone."
6. "What version of Android do I need? I have Android 9."
7. "So I need to update my phone to use the app? My phone can't go past Android 9."
8. "Is there another way to set up the bulb without the NovaMart Home app?"
9. "I also bought a smart thermostat. The listing said it's compatible with Alexa. How do I connect it?"
10. "The thermostat is showing an error code: E04. What does that mean?"
11. "Where can I find the manual for this thermostat? I threw away the box."
12. "Do you have video tutorials for setting up smart home devices?"
13. "I'm returning the bulb and the thermostat. Can I keep the smart plug that works?"
14. "Since two out of three devices don't work for me, can I get some kind of discount or credit?"
15. "Do you have a setup service where someone comes to my house and installs everything?"

---

## Set 15: Suspicious Activity & Account Security

> **Scenario:** Customer notices unfamiliar orders or charges on their account.

1. "I just got an email saying my order shipped, but I didn't place any order!"
2. "Someone might have hacked my account. How do I check recent login activity?"
3. "How do I change my password immediately?"
4. "I see two orders I didn't make totaling $430. Can you cancel them right now?"
5. "Can you tell me what IP address was used to place those orders?"
6. "I have 2FA enabled with SMS. How did someone still get into my account?"
7. "Should I switch to an authenticator app instead of SMS? Is that more secure?"
8. "The fraudulent orders were shipped to an address I don't recognize. Can you recall the packages?"
9. "Will I get a full refund for the orders I didn't place?"
10. "How long will the investigation take?"
11. "Do I need to call my bank too, or will you handle the charges?"
12. "Should I delete my saved payment methods?"
13. "Is my personal data safe? Could they have accessed my address and phone number?"
14. "Can you set up alerts so I get notified every time an order is placed on my account?"
15. "I want to keep my account but remove all saved addresses except my home. How do I do that?"

---

## Set 16: Eco-Conscious Customer

> **Scenario:** Customer specifically interested in sustainability and green products.

1. "I'm trying to reduce my environmental impact. Do you have eco-friendly products?"
2. "What does the 'Green Choice' badge mean exactly?"
3. "Can I filter search results to only show sustainable products?"
4. "What kind of packaging do you use? Is it recyclable?"
5. "I heard you offer frustration-free packaging. What is that exactly?"
6. "Is your standard shipping carbon neutral?"
7. "What about express shipping — is there a way to offset the carbon?"
8. "Do you have a recycling program for old electronics?"
9. "Can I bring old batteries to your store for recycling?"
10. "I want to return something. Can I use my own packaging instead of the original box to reduce waste?"
11. "Do you have a take-back program for old NovaMart products?"
12. "Where are your products manufactured? Do you ensure fair labor practices?"
13. "I love that your packing peanuts are biodegradable. Are they actually compostable?"

---

## Set 17: Complex Multi-Issue Order

> **Scenario:** Customer has one order with multiple problems — partial delivery, wrong size, and billing question.

1. "My order had 4 items but I only received 3. The tracking says delivered for all of them."
2. "One of the items I DID receive is the wrong size. I ordered Medium but got Large."
3. "I also noticed I was charged twice — once when I placed the order and again today."
4. "Let me deal with these one at a time. First, the missing item — it's a wireless mouse."
5. "How long will the investigation take for the missing item?"
6. "OK next, the wrong size shirt. Can I exchange it for a Medium instead of doing a full return?"
7. "Will the exchange shirt ship with Express since this was your error?"
8. "For the wrong size return, do I need to pay the $6.99 return label fee?"
9. "Now about the double charge — is one of those a pre-authorization hold?"
10. "How long until the extra charge drops off?"
11. "Can I get some kind of compensation for all these issues? Maybe a promo code or extra points?"
12. "What if the Medium shirt is out of stock when I try to exchange?"
13. "I also wanted to add NovaCare to the laptop that was part of this order. It arrived 2 weeks ago. Am I still within the window?"
14. "This has been really frustrating. Is there a way to escalate this to a supervisor?"

---

## Set 18: B2B / Bulk Buyer

> **Scenario:** Small business owner looking to buy in bulk for their office.

1. "I need to buy 25 identical laptop stands for our office. Is there a bulk discount?"
2. "Your website says maximum 10 units per order. How do I order 25?"
3. "Who do I contact for business/bulk orders?"
4. "Do you offer net-30 payment terms for businesses?"
5. "Can I get a VAT invoice for this purchase?"
6. "Do you offer corporate accounts with multiple users?"
7. "We need these shipped to three different office locations. Can you split a bulk order?"
8. "What's the warranty on bulk purchases? Same as individual?"
9. "If 5 of the 25 stands are defective, can I return just those 5?"
10. "Can we get a corporate NovaCare plan that covers all 25 units?"
11. "Do bulk orders earn rewards points?"
12. "We're a registered non-profit. Do you offer tax-exempt purchasing?"
13. "How quickly can you ship 25 units? We need them within a week."
14. "Can I set up recurring orders for office supplies like printer paper and coffee?"

---

## Set 19: Mobile App Issues

> **Scenario:** Customer having problems with the NovaMart mobile app.

1. "Your app keeps crashing every time I try to open my cart."
2. "I'm on iOS. What version of iOS does the app require?"
3. "I've cleared the cache and updated the app. Still crashing."
4. "Can I place the order through the website instead? Will my cart transfer?"
5. "I saved items to my wishlist in the app but they don't show on the website. Is that normal?"
6. "Push notifications stopped working. I used to get shipping updates on my phone."
7. "The app is showing a different price than the website for the same product. Which is correct?"
8. "Can I scan a barcode in-store using the app to check online prices?"
9. "I'm trying to use Apple Pay in the app but it won't work."
10. "Is there a way to chat with support directly through the app?"
11. "I get rewards points for downloading the app, right? I downloaded it but didn't get the points."
12. "Can I manage my auto-reorder subscriptions through the app?"

---

## Set 20: Post-Purchase Regret & Comparison Shopping

> **Scenario:** Customer bought something, now having second thoughts and comparing alternatives.

1. "I bought a pair of wireless earbuds yesterday for $149. Are they any good? The reviews seem mixed."
2. "I just saw the exact same earbuds at Best Buy for $129. Can you match that price?"
3. "Actually I think I want to return them and get the over-ear headphones instead. Can I do that?"
4. "If I return the earbuds and buy the headphones, do I lose the rewards points from the first purchase?"
5. "The headphones are $199 — that's $50 more. Can I use my rewards points to cover the difference?"
6. "How many points do I have? Where do I check?"
7. "It says I have 340 points. How much is that worth in dollars?"
8. "Is there a way to combine points + a promo code + my store credit on this order?"
9. "I haven't opened the earbuds yet. Can I return them in-store for an immediate refund and buy the headphones right there?"
10. "Do you have the headphones in your Austin store so I can try them before buying?"
11. "What's the return window on headphones? They're electronics right — so 15 days?"
12. "If I buy NovaCare for the headphones and then decide to return them, do I get refunded for NovaCare too?"
13. "Final question — the headphones say they're 'Certified Refurbished' for $159. What exactly does that mean? Is it safe to buy refurbished?"
