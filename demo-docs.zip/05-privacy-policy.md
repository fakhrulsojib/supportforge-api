# Privacy Policy & Data Protection

**Last Updated:** January 2025  
**Company:** NovaMart — Your Premium Online Marketplace

---

## Information We Collect

### Information You Provide
- **Account data:** Name, email address, phone number, password
- **Payment data:** Credit/debit card numbers, billing address (processed by Stripe — we never store full card numbers)
- **Shipping data:** Delivery address, recipient name
- **Communications:** Customer support tickets, chat transcripts, feedback, reviews

### Information Collected Automatically
- **Device data:** IP address, browser type, operating system, device identifiers
- **Usage data:** Pages visited, products viewed, search queries, time spent on site
- **Location data:** Approximate location based on IP address (we do not track GPS)
- **Cookies:** Session cookies (essential), analytics cookies, advertising cookies (opt-in only)

---

## How We Use Your Data

- **Order fulfillment:** Process payments, ship orders, send tracking notifications
- **Account management:** Maintain your account, save preferences, manage subscriptions
- **Customer support:** Respond to inquiries, resolve issues, process returns
- **Personalization:** Product recommendations, tailored search results, saved browsing history
- **Marketing:** Promotional emails and notifications (opt-in only, unsubscribe anytime)
- **Analytics:** Improve our website, products, and services
- **Fraud prevention:** Detect and prevent unauthorized transactions
- **Legal compliance:** Tax reporting, regulatory requirements

---

## Data Sharing

We do NOT sell your personal data. We share data only with:

- **Payment processors:** Stripe, PayPal (for transaction processing)
- **Shipping carriers:** USPS, UPS, FedEx, DHL (name and address for delivery)
- **Analytics providers:** Google Analytics (anonymized usage data)
- **Law enforcement:** Only when required by valid legal process (subpoena, court order)

---

## Your Rights (CCPA / GDPR)

- **Access:** Request a copy of all data we hold about you
- **Correction:** Update or correct inaccurate personal data
- **Deletion:** Request deletion of your account and personal data
- **Portability:** Receive your data in a machine-readable format
- **Opt-out:** Unsubscribe from marketing communications at any time
- **Restrict processing:** Limit how we use your data

### How to Exercise Your Rights
- **Self-service:** Account Settings → Privacy → "Download My Data" or "Delete My Account"
- **Email:** privacy@novamart.com
- **Phone:** 1-800-NOVA-MART, option 4
- **Response time:** Within 30 days of verified request

---

## Cookie Policy

| Cookie Type | Purpose | Required? |
|---|---|---|
| Essential | Login sessions, cart, security | Yes (site won't function without) |
| Analytics | Page views, user behavior (anonymized) | No (opt-in) |
| Marketing | Targeted ads, retargeting | No (opt-in) |
| Preferences | Language, theme, recently viewed | No (opt-in) |

Manage cookie preferences at novamart.com/cookie-settings or via the cookie banner.

---

## Data Security

- All data transmitted via 256-bit TLS/SSL encryption
- Payment data processed by PCI DSS Level 1 certified processors
- Employee access restricted on a need-to-know basis
- Regular security audits and penetration testing
- Data breach notification within 72 hours (as required by GDPR)
- Two-factor authentication available for all accounts

---

## Data Retention

| Data Type | Retention Period |
|---|---|
| Account data | Until account deletion + 90 days |
| Order history | 7 years (tax/legal requirements) |
| Payment data | Not stored (processed by Stripe) |
| Support tickets | 3 years after resolution |
| Analytics data | 26 months (anonymized) |
| Marketing preferences | Until opt-out or account deletion |

---

## Children's Privacy

- NovaMart accounts require users to be 18 years or older
- We do not knowingly collect personal data from children under 13 (COPPA compliance)
- Users between 13 and 17 may browse but cannot create accounts or make purchases
- If we discover we've collected data from a child under 13, we delete it immediately
- Parents/guardians can contact privacy@novamart.com to report concerns

---

## Contact

- **Privacy Officer:** privacy@novamart.com
- **Phone:** 1-800-NOVA-MART, option 4
- **Mail:** NovaMart Privacy Team, 100 Commerce Drive, Suite 500, Austin, TX 78701
