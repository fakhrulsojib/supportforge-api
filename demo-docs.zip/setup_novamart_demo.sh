#!/bin/bash
# NovaMart Demo Tenant Setup Script
# Creates a new tenant, registers an admin user, and uploads all demo documents
#
# Usage: ./setup_novamart_demo.sh [API_URL]
# Default API_URL: http://localhost:8000

set -e

API_URL="${1:-http://localhost:8000}"
DOCS_DIR="$(dirname "$0")"

echo "╔══════════════════════════════════════════════╗"
echo "║  NovaMart Demo Tenant Setup                  ║"
echo "║  SupportForge Knowledge Base Demo             ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "API: $API_URL"
echo ""

# Step 1: Create tenant
echo "━━━ Step 1: Creating NovaMart tenant ━━━"
TENANT_RESPONSE=$(curl -s -X POST "$API_URL/api/v1/tenants" \
  -H "Content-Type: application/json" \
  -d '{"name": "NovaMart", "slug": "novamart"}')

TENANT_ID=$(echo "$TENANT_RESPONSE" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    if 'id' in data:
        print(data['id'])
    elif 'error' in data and 'already exists' in data['error'].get('message','').lower():
        print('EXISTS')
    else:
        print('ERROR: ' + json.dumps(data))
except: print('ERROR')
" 2>/dev/null)

if [ "$TENANT_ID" = "EXISTS" ]; then
    echo "  ⚠ Tenant 'novamart' already exists. Fetching ID..."
    TENANT_ID=$(curl -s "$API_URL/api/v1/tenants/novamart" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])" 2>/dev/null)
fi

echo "  ✅ Tenant ID: $TENANT_ID"
echo ""

# Step 2: Register admin user
echo "━━━ Step 2: Registering admin user ━━━"
REGISTER_RESPONSE=$(curl -s -X POST "$API_URL/api/v1/auth/register" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"admin@novamart.com\",\"password\":\"NovaMart2025!@#\",\"tenant_id\":\"$TENANT_ID\",\"role\":\"admin\"}")

echo "  Response: $REGISTER_RESPONSE"
echo ""

# Step 3: Login to get token
echo "━━━ Step 3: Logging in ━━━"
LOGIN_RESPONSE=$(curl -s -X POST "$API_URL/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"admin@novamart.com\",\"password\":\"NovaMart2025!@#\",\"tenant_id\":\"$TENANT_ID\"}")

TOKEN=$(echo "$LOGIN_RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])" 2>/dev/null)

if [ -z "$TOKEN" ] || [ "$TOKEN" = "" ]; then
    echo "  ❌ Login failed: $LOGIN_RESPONSE"
    exit 1
fi
echo "  ✅ Logged in successfully"
echo ""

# Step 4: Upload all documents
echo "━━━ Step 4: Uploading knowledge base documents ━━━"

for doc in "$DOCS_DIR"/*.md; do
    filename=$(basename "$doc")
    if [ "$filename" = "README.md" ] || [ "$filename" = "setup_novamart_demo.sh" ]; then
        continue
    fi
    echo -n "  📄 Uploading $filename... "
    UPLOAD_RESPONSE=$(curl -s -X POST "$API_URL/api/v1/documents/upload" \
      -H "Authorization: Bearer $TOKEN" \
      -F "file=@$doc")
    echo "✅"
done

echo ""

# Step 5: Check uploaded documents
echo "━━━ Step 5: Verifying uploads ━━━"
DOCS_RESPONSE=$(curl -s "$API_URL/api/v1/documents" \
  -H "Authorization: Bearer $TOKEN")

DOC_COUNT=$(echo "$DOCS_RESPONSE" | python3 -c "
import sys, json
data = json.load(sys.stdin)
docs = data if isinstance(data, list) else data.get('documents', [])
print(len(docs))
" 2>/dev/null)

echo "  ✅ $DOC_COUNT documents in knowledge base"
echo ""

# Summary
echo "╔══════════════════════════════════════════════╗"
echo "║  ✅ Demo Setup Complete!                     ║"
echo "╠══════════════════════════════════════════════╣"
echo "║                                              ║"
echo "║  Tenant:    NovaMart                         ║"
echo "║  Tenant ID: $TENANT_ID  ║"
echo "║                                              ║"
echo "║  Login Credentials:                          ║"
echo "║  Email:    admin@novamart.com                ║"
echo "║  Password: NovaMart2025!@#                   ║"
echo "║                                              ║"
echo "║  Try asking:                                 ║"
echo "║  • What is the return policy?                ║"
echo "║  • How much does express shipping cost?      ║"
echo "║  • What does NovaCare warranty cover?        ║"
echo "║  • How do I reset my password?               ║"
echo "║  • What payment methods do you accept?       ║"
echo "║  • What is your privacy policy?              ║"
echo "║                                              ║"
echo "╚══════════════════════════════════════════════╝"
