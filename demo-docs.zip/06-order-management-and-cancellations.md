# Order Management & Cancellations

**Last Updated:** January 2025  
**Company:** NovaMart — Your Premium Online Marketplace

---

## Placing an Order

### How to Order
1. Browse or search for products on novamart.com or the NovaMart app
2. Select your item — choose size, color, quantity, and any customization options
3. Click "Add to Cart" — continue shopping or proceed to checkout
4. Review your cart — update quantities or remove items as needed
5. Proceed to checkout → enter or confirm your shipping address
6. Select a shipping method (Standard, Express, or Overnight)
7. Enter payment information or select a saved payment method
8. Apply promo codes, gift cards, or NovaMart Rewards under "Discounts"
9. Review your order summary, then click "Place Order"
10. You'll receive an order confirmation email within minutes

### Guest Checkout
- You can place an order without creating an account
- A guest order confirmation email includes a link to track your order
- To manage your order (returns, exchanges), you'll need to create an account using the same email
- Guest orders do not earn NovaMart Rewards points

### Order Limits
- Maximum 10 units of the same item per order (to prevent reselling abuse)
- High-demand or limited-edition items may have a lower purchase limit
- Business/bulk orders: contact sales@novamart.com for special pricing and limits

---

## Order Confirmation

After placing your order, you will receive:
1. **Confirmation email** — immediately after checkout (includes order number, items, total, estimated delivery)
2. **Preparation email** — when your order enters our warehouse queue (usually within 2–4 hours)
3. **Shipping confirmation** — when your order ships (includes tracking number and estimated delivery date)
4. **Delivery confirmation** — when the carrier marks your package as delivered

### Didn't Receive Confirmation?
- Check your spam/junk folder
- Verify the email address on your account (Account Settings → Profile)
- Log in to your account → "My Orders" — if the order appears, it was placed successfully
- If not listed, the order may not have been completed — try placing it again
- Contact support if you were charged but don't see the order

---

## Tracking Your Order

### Where to Track
- **Email:** Click the tracking link in your shipping confirmation email
- **My Orders:** Log in → "My Orders" → click the order → "Track Package"
- **NovaMart App:** Open the app → "Orders" tab → tap the active order
- **Carrier websites:** USPS.com, UPS.com, FedEx.com — enter your tracking number

### Understanding Tracking Statuses
| Status | What It Means |
|---|---|
| **Order Placed** | Order received, payment authorized |
| **Processing** | Order being prepared in our warehouse |
| **Shipped** | Package handed to carrier, tracking number active |
| **In Transit** | Package moving through carrier network |
| **Out for Delivery** | Package on the delivery vehicle, arriving today |
| **Delivered** | Package marked as delivered by carrier |
| **Delivery Attempted** | Carrier attempted delivery but no one was available |
| **Exception** | Issue with delivery — contact support |
| **Returned to Sender** | Package undeliverable — contact support for re-shipment |

### Multi-Package Orders
- Large orders may ship in multiple packages from different warehouses
- Each package has its own tracking number
- All tracking numbers are listed on your order details page
- You may receive packages on different days — this is normal

---

## Modifying an Order

### What Can Be Modified
- **Shipping address** — only before the order ships
- **Shipping method** — upgrade to Express or Overnight before shipment
- **Remove items** — cancel individual items from a multi-item order

### What Cannot Be Modified
- Payment method after order is placed
- Item customization (engraving, monogramming) once processing begins
- Adding items to an existing order — place a new order instead

### How to Modify
1. Log in → "My Orders" → select the order
2. Click "Modify Order" (only available while status is "Processing")
3. Make your changes and confirm
4. You'll receive an updated confirmation email

**Note:** Once an order enters the "Shipped" status, it cannot be modified. You'll need to return the item after delivery.

---

## Cancelling an Order

### When You Can Cancel
| Order Status | Can Cancel? | How |
|---|---|---|
| **Order Placed** (within 1 hour) | ✅ Yes — instant | "My Orders" → "Cancel Order" |
| **Processing** | ✅ Yes — may take up to 2 hours | "My Orders" → "Cancel Order" |
| **Shipped** | ❌ No | Wait for delivery, then initiate a return |
| **Delivered** | ❌ No | Initiate a return instead |

### How to Cancel
1. Log in → "My Orders" → select the order
2. Click "Cancel Order"
3. Select a reason for cancellation (helps us improve)
4. Confirm the cancellation
5. Refund is processed immediately to your original payment method
6. Pre-authorization holds are released within 3–5 business days (varies by bank)

### Partial Cancellation
- You can cancel individual items from a multi-item order
- Remaining items will still be shipped as scheduled
- Shipping costs are recalculated based on remaining items
- If remaining items qualify for free shipping ($50+), shipping cost is removed

### Automatic Cancellation
Orders may be automatically cancelled if:
- Payment authorization fails (insufficient funds, expired card)
- Address cannot be verified by the carrier
- Item goes out of stock after the order is placed (you'll be notified and refunded)
- Suspected fraudulent activity is detected

---

## Pre-Orders & Backorders

### Pre-Orders
- Pre-order items are clearly marked on the product page with an expected ship date
- Your card is charged at the time of the pre-order
- You can cancel a pre-order at any time before it ships for a full refund
- If the ship date changes, we'll notify you by email with the option to cancel
- Pre-order items ship separately from in-stock items

### Backorders
- If an item goes out of stock after you order it, you'll be notified by email
- Options: wait for restock (estimated date provided), cancel for a full refund, or select an alternative
- Backordered items ship as soon as they're back in stock — no additional shipping charge
- You can check backorder status anytime in "My Orders"

---

## Subscriptions & Auto-Reorder

### Setting Up Auto-Reorder
- Available on select consumable products (cleaning supplies, pet food, health items, etc.)
- Choose your delivery frequency: every 2, 4, 6, 8, or 12 weeks
- Save 10% on every auto-reorder compared to one-time purchase price
- Manage from "My Orders" → "Subscriptions"

### Managing Subscriptions
- **Skip a delivery:** Click "Skip" at least 3 days before the next order date
- **Change frequency:** Adjust delivery interval anytime
- **Swap products:** Switch to a different size, flavor, or variant
- **Cancel:** Cancel anytime from the Subscriptions page — no cancellation fees
- **Pause:** Pause your subscription for up to 3 months

### Auto-Reorder Billing
- Your saved payment method is charged 3 days before each scheduled shipment
- If payment fails, we'll retry once after 2 days and notify you by email
- After 2 failed payment attempts, the subscription is paused (not cancelled)
- You can update your payment method and resume at any time

---

## Gift Orders

### Sending a Gift
- During checkout, check the "This is a gift" box
- Add a personalized gift message (up to 200 characters, free)
- Choose gift wrapping: Standard ($4.99) or Premium ($9.99)
- Prices are hidden from the packing slip

### Gift Receipts
- A gift receipt is included in the package if "This is a gift" is selected
- Gift receipts show items but not prices
- The recipient can use the gift receipt to initiate returns or exchanges (refunded as store credit)

### Digital Gift Cards
- Available in amounts from $10 to $500
- Delivered instantly via email to the recipient
- Never expire and have no fees
- Can be redeemed at checkout on novamart.com or the NovaMart app
- If the recipient hasn't received the email, they should check spam/junk folders

---

## Order Issues & Resolutions

### Item Out of Stock After Order
- We'll notify you by email within 24 hours
- Options: wait for restock, cancel the item for a refund, or choose an alternative
- If part of a multi-item order, remaining items ship as normal

### Incorrect Item Received
- Contact support within 14 days of delivery
- We ship the correct item immediately via Express Shipping at no cost
- A prepaid return label is provided for the incorrect item
- You don't need to wait for the return to receive the correct item

### Missing Items From Order
- Check if your order shipped in multiple packages (see tracking details)
- If all packages are delivered and an item is missing, contact support
- We'll investigate and ship the missing item or issue a refund within 2 business days

### Duplicate Charges
- Check if your order shipped in multiple packages (each shipment may appear as a separate charge)
- A pre-authorization hold may appear alongside the actual charge (the hold will drop off in 3–5 business days)
- If you see a genuine duplicate charge after 5 business days, contact support with your order number

---

## Contact Order Support

- **Email:** orders@novamart.com
- **Phone:** 1-800-NOVA-MART (1-800-668-2627), option 1 for order support
- **Hours:** Monday–Friday, 8:00 AM – 8:00 PM EST; Saturday, 9:00 AM – 5:00 PM EST
- **Live Chat:** Available at novamart.com during business hours
- **Self-Service:** Most order actions (cancel, modify, track, return) can be done from "My Orders" in your account
