# Returns & Refunds Policy

**Last Updated:** January 2025  
**Company:** NovaMart — Your Premium Online Marketplace

---

## Return Window

- **Standard Products:** 30 days from the date of delivery
- **Electronics:** 15 days from the date of delivery
- **Seasonal/Sale Items:** 14 days from the date of delivery (final sale items are not returnable)
- **Furniture & Large Items:** 30 days from delivery, subject to a 15% restocking fee

---

## Eligibility for Returns

### Returnable Items
- Items in original, unused condition with all tags attached
- Items in original packaging with all accessories, manuals, and parts included
- Items with a valid proof of purchase (order confirmation email or receipt)

### Non-Returnable Items
- Personalized or custom-made products
- Undergarments, swimwear, and intimate apparel (for hygiene reasons)
- Gift cards
- Downloadable software and digital products
- Perishable goods (food, flowers, etc.)
- Items marked as "Final Sale" on the product page
- Products that have been altered, washed, or damaged by the customer
- Hazardous materials

---

## How to Initiate a Return

### Online Returns (Recommended)
1. Log in to your NovaMart account
2. Go to "My Orders" and select the order containing the item(s) you wish to return
3. Click "Return Item" and select the reason for return
4. Choose your preferred return method:
   - **Free drop-off** at a NovaMart partner location (UPS Store, FedEx Office)
   - **Prepaid shipping label** (deducted from refund: $6.99 for Standard, free for defective or sizing-related items)
   - **Home pickup** available in select areas for an additional $9.99
5. Pack the item securely in its original packaging
6. Attach the return label and drop off at the designated carrier

### In-Store Returns
- Bring the item and your proof of purchase to any NovaMart retail location
- Returns are processed immediately
- Refund is issued to your original payment method

### Customer Support Returns
- Call 1-800-NOVA-MART (1-800-668-2627) or email returns@novamart.com
- A representative will guide you through the process
- A prepaid return label will be emailed to you within 24 hours

---

## Refund Processing

### Refund Methods
| Original Payment Method | Refund Method | Processing Time |
|---|---|---|
| Credit/Debit Card | Refund to same card | 5–10 business days |
| PayPal | Refund to PayPal account | 3–5 business days |
| NovaMart Gift Card | Refund to gift card balance | 1–2 business days |
| Buy Now, Pay Later (Affirm/Klarna) | Refund to BNPL account | 5–10 business days |
| Apple Pay / Google Pay | Refund to linked card | 5–10 business days |

### Refund Timeline
1. **Return received:** We inspect the item within 2 business days of receipt
2. **Refund initiated:** If approved, refund is processed within 1 business day after inspection
3. **Refund posted:** Depending on your payment method, it takes 3–10 business days to appear on your statement

### Partial Refunds
A partial refund may be issued if:
- The item shows signs of use or wear
- The item is returned without original packaging or accessories
- The item is returned outside the standard return window (at our discretion)
- A restocking fee applies (furniture, large items — waived for defective or damaged items)

---

## Exchanges

- We process exchanges as a new order + return
- To exchange an item, initiate a return and place a new order for the desired item
- If the exchange item is a different price, you will be charged or refunded the difference
- We recommend placing the new order immediately to avoid stock-outs

---

## Defective or Damaged Items

If you receive a defective or damaged item:
1. **Do not discard the item or packaging** — take photos showing the damage
2. Contact support within 7 days of delivery
3. We will offer one of the following at no cost to you:
   - **Full replacement** shipped via Express Shipping
   - **Full refund** to your original payment method
   - **Store credit** with a 10% bonus (e.g., $50 item → $55 store credit)
4. You may be asked to return the defective item using a prepaid label
5. In some cases, you may keep the defective item (for low-value items under $25)

---

## Late Returns

Returns received after the standard return window may be accepted at our discretion:
- Items returned within 31–45 days: Store credit only (no cash refund)
- Items returned after 45 days: Not eligible for return or credit
- **NovaMart Premium Members:** Extended return window of 60 days for all eligible items (non-returnable items excluded)

---

## Frequently Asked Questions

**Q: Can I return an item without the original packaging?**
A: We strongly recommend returning items in their original packaging. Items returned without packaging may be subject to a partial refund or may be denied.

**Q: Can I return a gift?**
A: Yes, gift returns are processed as store credit. The person who placed the order will not be notified.

**Q: What if my refund hasn't appeared after 10 business days?**
A: Contact your bank or payment provider first. If the issue persists, contact NovaMart support with your order number and return tracking number.

**Q: Can I cancel an order instead of returning it?**
A: Yes, if your order status is still "Order Placed" or "Processing," you can cancel it from "My Orders" for a full refund. Once the order has shipped, you'll need to wait for delivery and initiate a return.

---

## Contact Information

- **Email:** returns@novamart.com
- **Phone:** 1-800-NOVA-MART (1-800-668-2627)
- **Hours:** Monday–Friday, 8:00 AM – 8:00 PM EST; Saturday, 9:00 AM – 5:00 PM EST
- **Returns Portal:** novamart.com/returns
