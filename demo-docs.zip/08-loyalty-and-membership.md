# NovaMart Premium Membership & Rewards

**Last Updated:** January 2025  
**Company:** NovaMart — Your Premium Online Marketplace

---

## NovaMart Rewards Program

### How to Join
- Rewards enrollment is **free and automatic** when you create a NovaMart account
- Start earning points on your very first purchase
- No minimum purchase required to start earning

### Earning Points
| Activity | Points Earned |
|---|---|
| Every $1 spent on purchases | 1 point |
| Writing a product review | 25 points |
| Referring a friend (after their first purchase) | 500 points |
| Birthday bonus (every year) | 100 points |
| First purchase after joining | 50 bonus points |
| Completing your profile (address, phone, preferences) | 25 points |
| Downloading the NovaMart app | 50 points |

- Points are earned on the item subtotal (excluding tax, shipping, and gift card purchases)
- Points are credited **30 days after delivery** to allow for returns
- If an item is returned, the associated points are deducted from your balance

### Redeeming Points
- **100 points = $5 discount** on your next order
- Minimum redemption: 50 points ($2.50 discount)
- Apply points at checkout under "NovaMart Rewards"
- Points can be combined with promo codes unless specifically excluded
- Points cannot be used to purchase gift cards
- Points have no cash value and are non-transferable

### Points Expiration
- Points expire **12 months** after the date they were earned
- If you make at least one purchase every 12 months, all points remain active
- You'll receive an email notification 30 days before any points expire
- Expired points cannot be reinstated

### Membership Tiers

| Tier | Annual Spend | Points Multiplier | Key Benefits |
|---|---|---|---|
| **Bronze** | $0–$499 | 1x | Birthday bonus, basic rewards |
| **Silver** | $500–$1,499 | 1.5x | Early access to sales (24 hours before public) |
| **Gold** | $1,500–$4,999 | 2x | Free Express shipping, priority customer support |
| **Platinum** | $5,000+ | 3x | Free Overnight shipping, dedicated account manager, exclusive events |

- Tier status is based on your **calendar year** spending (January 1 – December 31)
- You maintain your tier for the **full following year** after qualifying
- If you don't re-qualify, you drop one tier (never more than one per year)
- Tier progress is visible in your account under "My Rewards"

### Tier Benefits in Detail

**Bronze (all members)**
- Earn 1 point per $1 spent
- 100-point birthday bonus
- Access to member-only flash sales
- Early access to clearance events

**Silver ($500+ annual spend)**
- Everything in Bronze, plus:
- 1.5x points on all purchases (e.g., $100 purchase = 150 points)
- 24-hour early access to seasonal sales (Black Friday, Summer Sale, etc.)
- Free Standard shipping on all orders (no $50 minimum)
- Quarterly members-only coupon (10% off)

**Gold ($1,500+ annual spend)**
- Everything in Silver, plus:
- 2x points on all purchases
- Free Express shipping on all orders
- Priority customer support (shorter wait times, dedicated queue)
- Free gift wrapping on all orders
- Extended return window: 45 days (vs. standard 30 days)
- Annual $25 reward certificate

**Platinum ($5,000+ annual spend)**
- Everything in Gold, plus:
- 3x points on all purchases
- Free Overnight shipping on all orders
- Dedicated account manager (direct email and phone line)
- Invitations to exclusive NovaMart events and product launches
- Extended return window: 60 days
- Annual $100 reward certificate
- Complimentary NovaCare Basic warranty on all electronics purchases
- Early access to new products and sales (48 hours before public)

---

## NovaMart Premium Membership

### What is NovaMart Premium?
NovaMart Premium is a paid subscription that gives you the best NovaMart has to offer — unlimited free Express shipping, double points, extended returns, and exclusive deals.

### Plans & Pricing
| Plan | Price | Savings vs. Monthly |
|---|---|---|
| **Monthly** | $9.99/month | — |
| **Annual** | $99/year | Save $20.88/year |
| **Student** | $49/year | 50% off with valid .edu email |

### Premium Benefits
- ✅ **Free Express shipping** on every order within the continental US, no minimum purchase
- ✅ **2x bonus points** on all purchases (stacks with tier multiplier)
- ✅ **Extended 60-day return window** on all eligible items (non-returnable items excluded)
- ✅ **Exclusive member-only pricing** on select products (look for the "Premium Price" badge)
- ✅ **Early access** to new products and sales (48 hours before public)
- ✅ **Free gift wrapping** on all orders
- ✅ **Priority customer support** — skip the queue with a dedicated Premium support line
- ✅ **Monthly Premium deal** — an exclusive high-value coupon delivered to your inbox every month
- ✅ **Free NovaCare Basic** warranty on electronics under $200

### Premium + Rewards Tier Stacking
Premium benefits stack with your Rewards tier:
- **Points:** Your tier multiplier + Premium's 2x bonus are added together
  - Premium + Gold = 2x + 2x = **4x points** per dollar
  - Premium + Platinum = 3x + 2x = **5x points** per dollar
- **Return window:** The longer window applies (e.g., Gold's 45 days vs. Premium's 60 days → you get 60 days)
- **Shipping:** The fastest free shipping tier applies (e.g., Gold's Express vs. Platinum's Overnight → you get Overnight)
- **All other benefits** from both your tier and Premium are combined

### How to Subscribe
1. Go to novamart.com/premium or Account Settings → "Go Premium"
2. Choose Monthly or Annual plan
3. Enter payment information
4. Benefits activate immediately — your next order ships with free Express

### Managing Your Subscription
- View your plan: Account Settings → "Premium Membership"
- Switch between Monthly and Annual plans anytime
- Cancel anytime — your benefits continue until the end of the current billing period
- No cancellation fees or penalties
- Resubscribe anytime to instantly restore all benefits

### Premium Student Plan
- Available to students with a valid .edu email address
- Verify your student status during signup (instant verification via SheerID)
- Re-verification required annually
- All standard Premium benefits included
- Graduates can switch to a regular Premium plan at the standard rate

### Premium Family Sharing
- Premium members can share benefits with up to **2 household members**
- Shared members get: free Express shipping and extended returns
- Points and rewards are NOT shared — each member earns independently
- Add family members from Account Settings → "Premium" → "Family Sharing"

---

## Referral Program

### How It Works
1. Share your unique referral link from Account Settings → "Refer a Friend"
2. Your friend gets **$10 off** their first order of $50+
3. You get **500 Rewards points** ($25 value) when they complete their first purchase
4. No limit on the number of friends you can refer

### Referral Rules
- The referred friend must be a **new NovaMart customer** (never placed an order before)
- The friend must place their first order within 90 days of clicking your referral link
- Your 500 points are credited 30 days after your friend's first delivery
- Self-referrals are not permitted and will be forfeited
- Referral rewards cannot be combined with other new-customer promotions

---

## Gift Cards & Store Credit

### Gift Cards
- Available in amounts from $10 to $500 (digital or physical)
- **Digital gift cards:** Delivered instantly via email, customizable message
- **Physical gift cards:** Shipped in a gift box, available via Standard or Express shipping
- Gift cards **never expire** and have **no fees**
- Can be redeemed on novamart.com or the NovaMart app
- Multiple gift cards can be applied to a single order
- Gift cards cannot be used to purchase other gift cards
- Lost or stolen physical gift cards: contact support with proof of purchase for a replacement

### Checking Your Gift Card Balance
- Online: novamart.com/giftcard-balance — enter the card number and PIN
- App: Account → "Gift Cards & Credits" → enter card details
- Phone: Call 1-800-NOVA-MART, option 6

### Store Credit
- Issued for gift returns, goodwill credits, and select promotional offers
- Store credit never expires
- Applied automatically at checkout if available
- View your balance: Account Settings → "Gift Cards & Credits"
- Store credit cannot be transferred to another account or converted to cash

---

## Frequently Asked Questions

**Q: How do I check my Rewards points balance?**
A: Log in → click your avatar → "My Rewards." Your balance, tier status, and points history are all displayed.

**Q: Can I earn points on sale or discounted items?**
A: Yes! Points are earned on the final amount you pay for the item (after discounts, before tax and shipping).

**Q: What happens to my points if I return an item?**
A: Points earned from the returned item are deducted from your balance. If you don't have enough points, your balance may go negative until your next purchase.

**Q: Can I gift my Rewards points to someone else?**
A: No, Rewards points are non-transferable and tied to your account.

**Q: I'm a Premium member but was charged for shipping. Why?**
A: Premium includes free Express shipping within the continental US. Alaska, Hawaii, and international orders may have additional shipping charges. Also, oversized or freight items (over 150 lbs) are excluded.

**Q: Can I pause my Premium membership?**
A: You can cancel anytime and resubscribe later, but there is no pause option. When you cancel, benefits remain active until the end of your current billing cycle.

**Q: How do I know if a product has a Premium Price?**
A: Look for the purple "Premium Price" badge on product pages. The discounted price is shown alongside the regular price.

---

## Contact Rewards & Premium Support

- **Email:** rewards@novamart.com
- **Premium/Platinum hotline:** 1-800-NOVA-MART, option 7 (Premium and Platinum members — no wait times)
- **Phone:** 1-800-NOVA-MART (1-800-668-2627), option 6 for Rewards questions
- **Hours:** Monday–Friday, 8:00 AM – 8:00 PM EST; Saturday, 9:00 AM – 5:00 PM EST
- **Live Chat:** Available at novamart.com during business hours
- **Help Center:** novamart.com/rewards-help
