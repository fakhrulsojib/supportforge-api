# Contact Us & Store Policies

**Last Updated:** January 2025  
**Company:** NovaMart — Your Premium Online Marketplace

---

## How to Reach Us

### Customer Support Phone
- **Number:** 1-800-NOVA-MART (1-800-668-2627)
- **Hours:** Monday–Friday, 8:00 AM – 8:00 PM EST; Saturday, 9:00 AM – 5:00 PM EST
- **Closed:** Sundays and federal holidays (New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving, Christmas Day)

#### Phone Menu Options
| Option | Department |
|---|---|
| 1 | Order status, tracking, modifications, and cancellations |
| 2 | Product questions and recommendations |
| 3 | Warranty claims and NovaCare support |
| 4 | Privacy, data requests, and account deletion |
| 5 | Technical support and troubleshooting |
| 6 | Rewards, gift cards, and Premium membership |
| 7 | Premium and Platinum member priority line |
| 0 | Speak to a general representative |

### Email Support
| Department | Email | Response Time |
|---|---|---|
| General support | support@novamart.com | Within 24 hours |
| Orders | orders@novamart.com | Within 12 hours |
| Returns | returns@novamart.com | Within 24 hours |
| Warranty | warranty@novamart.com | Within 24 hours |
| Technical support | techsupport@novamart.com | Within 24 hours |
| Privacy | privacy@novamart.com | Within 48 hours |
| Rewards & Premium | rewards@novamart.com | Within 24 hours |
| Business/bulk orders | sales@novamart.com | Within 48 hours |
| Sizing help | sizing@novamart.com | Within 24 hours |
| Press inquiries | press@novamart.com | Within 48 hours |
| Partnerships | partners@novamart.com | Within 5 business days |

### Live Chat
- Available on novamart.com and the NovaMart app during business hours
- Click the chat icon in the bottom-right corner
- Average wait time: under 2 minutes (under 30 seconds for Premium and Platinum members)
- Chat transcripts are emailed to you automatically after the conversation ends

### Social Media Support
- **Twitter/X:** @NovaMartSupport — DMs monitored during business hours
- **Instagram:** @NovaMart — DMs monitored during business hours
- **Facebook:** facebook.com/NovaMart — Messenger monitored during business hours
- **Response time:** Within 4 hours during business hours

### Self-Service Help Center
- **URL:** novamart.com/help
- Browse FAQs, how-to guides, troubleshooting articles, and video tutorials
- Search by topic or product
- Most common questions can be resolved without contacting support

### NovaMart Community Forum
- **URL:** community.novamart.com
- Ask questions, share tips, and get advice from other NovaMart customers
- Product discussions, deal alerts, and setup guides
- Moderated by NovaMart staff — official responses marked with a "NovaMart Team" badge

---

## Retail Store Locations

### Store Hours
- **Monday–Saturday:** 10:00 AM – 9:00 PM (local time)
- **Sunday:** 11:00 AM – 6:00 PM (local time)
- **Holiday hours:** Vary by location — check novamart.com/stores for your local store

### Services Available In-Store
- **Product demos:** Try before you buy — hands-on demos for electronics, appliances, and smart home devices
- **Expert consultations:** Free 15-minute consultations with product specialists (walk-in or book online)
- **In-store returns:** Instant returns with proof of purchase — no waiting for mail-in processing
- **Order pickup:** Buy online, pick up in store within 2 hours (select items)
- **Repairs:** Drop off devices for in-warranty or out-of-warranty repair
- **Trade-in:** Trade in old electronics for NovaMart store credit (see Trade-In Program below)
- **Gift wrapping:** Available for a small fee — or free for Gold, Platinum, and Premium members
- **NovaCare enrollment:** Purchase NovaCare extended warranty plans in-store

### Finding a Store
- Visit novamart.com/stores or use the NovaMart app → "Find a Store"
- Enter your ZIP code or city to find the nearest location
- View store hours, directions, available services, and current in-store events

---

## Trade-In Program

### How It Works
1. Go to novamart.com/trade-in or visit any NovaMart store
2. Select your product category and answer a few condition questions
3. Receive an instant trade-in estimate
4. Ship your device (prepaid label provided) or bring it to a store
5. Once inspected and verified, store credit is added to your account within 3 business days

### Eligible Products
- Smartphones, tablets, laptops, smartwatches, gaming consoles, headphones
- Items must power on and be free of major damage (cracked screens accepted at reduced value)
- All personal data must be erased before trade-in (factory reset)

### Trade-In Value Examples
| Product | Good Condition | Fair Condition | Poor Condition |
|---|---|---|---|
| iPhone 15 (128GB) | Up to $350 | Up to $250 | Up to $120 |
| Samsung Galaxy S24 | Up to $300 | Up to $200 | Up to $100 |
| iPad Air (5th gen) | Up to $250 | Up to $175 | Up to $80 |
| MacBook Air M2 | Up to $500 | Up to $350 | Up to $200 |
| PlayStation 5 | Up to $200 | Up to $140 | Up to $75 |
| AirPods Pro (2nd gen) | Up to $80 | Up to $50 | Up to $25 |

*Values are estimates and may vary based on market conditions and device inspection.*

---

## Accessibility

### Our Commitment
NovaMart is committed to making our website, app, and stores accessible to everyone, including customers with disabilities.

### Website & App Accessibility
- Our website and app comply with **WCAG 2.1 Level AA** standards
- Features include: keyboard navigation, screen reader compatibility, alt text for images, high-contrast mode, resizable text, and captions on video content
- We regularly audit and test our digital properties for accessibility

### Assistive Shopping
- **Phone orders:** If you have difficulty using our website, call 1-800-NOVA-MART and a representative will place the order for you at no additional charge
- **TTY/TDD:** Available at 1-800-NOVA-TTY (1-800-668-2889) for deaf and hard-of-hearing customers
- **Video Relay Service (VRS):** Supported — call our main number through your VRS provider

### In-Store Accessibility
- All NovaMart retail stores are ADA-compliant
- Wheelchair-accessible entrances, aisles, and restrooms
- Service animals welcome
- Assistive listening devices available at customer service desk
- Large-print price tags available upon request

### Feedback
If you encounter any accessibility barriers, please contact us:
- **Email:** accessibility@novamart.com
- **Phone:** 1-800-NOVA-MART, option 0 → ask for Accessibility Services
- We investigate and respond to all accessibility feedback within 5 business days

---

## Sustainability & Environmental Policy

### Our Commitment
NovaMart is committed to reducing our environmental impact through responsible sourcing, packaging, and operations.

### Sustainable Packaging
- All NovaMart-branded packaging is made from **100% recycled materials**
- Our packing peanuts are **biodegradable cornstarch** (dissolve in water)
- We use right-sized boxes to minimize waste and reduce shipping emissions
- Customers can opt for **"Frustration-Free Packaging"** at checkout — minimal packaging, no plastic, easy to open and recycle

### Carbon-Neutral Shipping
- All Standard Shipping orders are **carbon-neutral** — we offset emissions through verified carbon credit programs
- Express and Overnight orders: customers can opt in to carbon offset at checkout for $0.99

### NovaMart Green Collection
- Look for the 🌱 **"Green Choice"** badge on product pages
- Products with this badge meet at least one of the following: made from recycled materials, sustainably sourced, energy-efficient, organic, or cruelty-free
- Filter by "Green Choice" in any product category to browse sustainable options

### Recycling Program
- Drop off used packaging at any NovaMart store for recycling
- Electronics recycling available in-store (e-waste must be handled properly)
- Old batteries can be recycled at customer service — we accept all common battery types

---

## Price & Product Policies

### Price Match Guarantee
- NovaMart matches prices within **7 days** of your purchase
- The competitor must be an authorized retailer (Amazon, Best Buy, Target, Walmart, or brand direct)
- The product must be **identical**: same brand, model, color, and size
- The competitor price must be publicly available (no membership-only, employee, or coupon prices)
- Marketplace/third-party seller prices are not eligible
- Contact support with a link to the competitor's product page

### Price Drop Protection
- If an item you purchased drops in price within **14 days of delivery**, we'll refund the difference
- Applies to NovaMart direct sales only (not marketplace sellers)
- Excludes clearance, flash sales, and holiday event pricing (Black Friday, Cyber Monday, Prime Day)
- Automatically applied if you have NovaMart Premium; otherwise, contact support

### Product Authenticity
- All products sold directly by NovaMart are **100% authentic and brand-authorized**
- We source from authorized distributors and brand partners only
- NovaMart does not sell counterfeit, gray-market, or unauthorized goods
- If you believe you received a counterfeit product, contact support immediately — we'll investigate and replace or refund

### Product Availability
- Products are available while supplies last
- We do our best to maintain accurate stock levels, but occasionally items sell out between adding to cart and checkout
- If an item becomes unavailable after you order, we'll notify you within 24 hours with options: wait for restock, select an alternative, or receive a full refund
- Use "Notify Me" on out-of-stock product pages to receive an email when the item is back

### Product Reviews
- Only verified purchasers can leave reviews
- Reviews must follow our Community Guidelines (no profanity, personal attacks, or off-topic content)
- Star ratings: 1 (Poor) to 5 (Excellent)
- Reviews with photos or videos receive priority visibility
- NovaMart does not pay for or incentivize reviews — all reviews are genuine customer opinions
- If you received a defective product, we encourage you to contact support first — we may be able to resolve the issue before you review

---

## Legal & Compliance

### Terms of Service
- Full Terms of Service available at novamart.com/terms
- By using NovaMart, you agree to our Terms of Service and Privacy Policy
- Terms may be updated periodically — material changes are communicated via email

### Sales Tax
- NovaMart collects sales tax as required by law based on your shipping address
- Tax rates vary by state, county, and municipality
- Tax is calculated during checkout and shown before you place your order
- Tax-exempt customers (non-profits, resellers): submit your exemption certificate to tax@novamart.com

### International Customers
- NovaMart ships internationally to over 50 countries
- International prices are shown in USD; your bank may charge a currency conversion fee
- Customs duties, import taxes, and brokerage fees are the responsibility of the customer
- International orders are not eligible for free shipping promotions
- Return shipping for international orders is the customer's responsibility (except for defective items)

---

## Contact Information Summary

| Need | Contact |
|---|---|
| **General questions** | support@novamart.com or 1-800-NOVA-MART |
| **Order help** | orders@novamart.com or option 1 |
| **Returns** | returns@novamart.com or novamart.com/returns |
| **Warranty** | warranty@novamart.com or option 3 |
| **Tech support** | techsupport@novamart.com or option 5 |
| **Privacy/data** | privacy@novamart.com or option 4 |
| **Rewards** | rewards@novamart.com or option 6 |
| **Premium/Platinum support** | 1-800-NOVA-MART, option 7 |
| **Accessibility** | accessibility@novamart.com |
| **Mailing address** | NovaMart, Inc., 100 Commerce Drive, Suite 500, Austin, TX 78701 |
