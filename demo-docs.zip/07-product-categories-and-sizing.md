# Product Categories & Sizing Guide

**Last Updated:** January 2025  
**Company:** NovaMart — Your Premium Online Marketplace

---

## Product Categories

NovaMart offers a curated selection of premium products across the following categories:

### Electronics & Technology
- **Laptops & Computers:** Windows laptops, MacBooks, Chromebooks, desktops, monitors
- **Smartphones & Tablets:** Latest models from Apple, Samsung, Google, OnePlus
- **Audio:** Wireless earbuds, over-ear headphones, Bluetooth speakers, soundbars
- **Smart Home:** Smart plugs, smart bulbs, security cameras, thermostats, doorbells, robot vacuums
- **Accessories:** Cases, chargers, cables, screen protectors, stands, docking stations
- **Gaming:** Consoles (PlayStation, Xbox, Nintendo), controllers, gaming headsets, gaming chairs

### Home & Kitchen
- **Kitchen Appliances:** Blenders, air fryers, coffee makers, toasters, stand mixers, instant pots
- **Cookware:** Non-stick pans, cast iron skillets, knife sets, cutting boards, bakeware
- **Storage & Organization:** Shelving, storage bins, drawer organizers, closet systems
- **Cleaning:** Robot vacuums, steam mops, cordless vacuums, cleaning supplies
- **Home Décor:** Wall art, throw pillows, candles, vases, clocks, mirrors

### Furniture
- **Living Room:** Sofas, sectionals, coffee tables, TV stands, bookshelves, accent chairs
- **Bedroom:** Bed frames, mattresses, nightstands, dressers, wardrobes
- **Office:** Desks (standing & sitting), ergonomic chairs, filing cabinets, monitor arms
- **Outdoor:** Patio sets, lounge chairs, outdoor dining, umbrellas, planters
- **Assembly:** Most furniture requires assembly; manuals and video guides available at novamart.com/manuals

### Clothing & Apparel
- **Men's:** T-shirts, polos, dress shirts, jeans, chinos, jackets, suits, activewear
- **Women's:** Tops, blouses, dresses, skirts, jeans, jackets, activewear
- **Shoes:** Sneakers, boots, sandals, dress shoes, athletic shoes
- **Accessories:** Watches, sunglasses, belts, wallets, bags, hats, scarves

### Sports & Outdoors
- **Fitness:** Dumbbells, resistance bands, yoga mats, foam rollers, jump ropes
- **Cycling:** Bikes, helmets, locks, lights, water bottles, repair kits
- **Camping:** Tents, sleeping bags, lanterns, coolers, portable stoves
- **Water Sports:** Kayaks, paddleboards, life jackets, dry bags

### Health & Beauty
- **Skincare:** Cleansers, moisturizers, serums, sunscreen, face masks
- **Hair Care:** Shampoos, conditioners, hair dryers, straighteners, styling products
- **Personal Care:** Electric toothbrushes, razors, trimmers, wellness devices
- **Supplements:** Vitamins, protein powders, collagen, probiotics

### Kids & Baby
- **Toys & Games:** Building sets, board games, educational toys, outdoor play
- **Baby Gear:** Strollers, car seats, high chairs, cribs, baby monitors
- **Kids' Clothing:** Sizes newborn to 14 years
- **School Supplies:** Backpacks, lunch boxes, water bottles, stationery

---

## Clothing Sizing Guide

### How to Measure
For the best fit, take measurements wearing lightweight clothing:

1. **Chest/Bust:** Measure around the fullest part of your chest, keeping the tape level
2. **Waist:** Measure around your natural waistline (the narrowest part of your torso)
3. **Hips:** Measure around the fullest part of your hips
4. **Inseam:** Measure from the crotch seam to the bottom of the leg along the inner seam
5. **Sleeve:** Measure from the center back of your neck, across your shoulder, down to your wrist

### Men's Clothing Sizes

| Size | Chest (in) | Waist (in) | Hip (in) |
|---|---|---|---|
| **XS** | 32–34 | 26–28 | 32–34 |
| **S** | 35–37 | 29–31 | 35–37 |
| **M** | 38–40 | 32–34 | 38–40 |
| **L** | 41–43 | 35–37 | 41–43 |
| **XL** | 44–46 | 38–40 | 44–46 |
| **XXL** | 47–49 | 41–43 | 47–49 |
| **3XL** | 50–52 | 44–46 | 50–52 |

### Men's Pants Sizes

| Size | Waist (in) | Inseam (in) |
|---|---|---|
| **28** | 28 | 30 or 32 |
| **30** | 30 | 30 or 32 |
| **32** | 32 | 30 or 32 |
| **34** | 34 | 30 or 32 |
| **36** | 36 | 30 or 32 |
| **38** | 38 | 30 or 32 |
| **40** | 40 | 30 or 32 |

### Women's Clothing Sizes

| Size | US Size | Bust (in) | Waist (in) | Hip (in) |
|---|---|---|---|---|
| **XS** | 0–2 | 31–33 | 24–26 | 34–36 |
| **S** | 4–6 | 34–36 | 27–29 | 37–39 |
| **M** | 8–10 | 37–39 | 30–32 | 40–42 |
| **L** | 12–14 | 40–42 | 33–35 | 43–45 |
| **XL** | 16–18 | 43–45 | 36–38 | 46–48 |
| **XXL** | 20–22 | 46–48 | 39–41 | 49–51 |

### Women's Dress Sizes

| US Size | UK Size | EU Size |
|---|---|---|
| 0 | 4 | 32 |
| 2 | 6 | 34 |
| 4 | 8 | 36 |
| 6 | 10 | 38 |
| 8 | 12 | 40 |
| 10 | 14 | 42 |
| 12 | 16 | 44 |
| 14 | 18 | 46 |

---

## Shoe Sizing Guide

### How to Measure Your Feet
1. Stand on a piece of paper with your heel against a wall
2. Mark the longest point of your foot (tip of your longest toe)
3. Measure the distance from the wall to the mark in inches or centimeters
4. Use the chart below to find your size
5. If you're between sizes, we recommend ordering the larger size

### Men's Shoe Sizes

| US | UK | EU | Foot Length (in) | Foot Length (cm) |
|---|---|---|---|---|
| 7 | 6 | 40 | 9.63 | 24.4 |
| 8 | 7 | 41 | 9.94 | 25.2 |
| 9 | 8 | 42 | 10.25 | 26.0 |
| 10 | 9 | 43 | 10.56 | 26.8 |
| 11 | 10 | 44 | 10.94 | 27.8 |
| 12 | 11 | 45 | 11.25 | 28.6 |
| 13 | 12 | 46 | 11.56 | 29.4 |

### Women's Shoe Sizes

| US | UK | EU | Foot Length (in) | Foot Length (cm) |
|---|---|---|---|---|
| 5 | 3 | 35 | 8.50 | 21.6 |
| 6 | 4 | 36 | 8.81 | 22.4 |
| 7 | 5 | 37 | 9.19 | 23.3 |
| 8 | 6 | 38 | 9.50 | 24.1 |
| 9 | 7 | 39 | 9.81 | 24.9 |
| 10 | 8 | 40 | 10.19 | 25.9 |
| 11 | 9 | 41 | 10.50 | 26.7 |

### Kids' Shoe Sizes

| US Kids | UK | EU | Age (approx.) |
|---|---|---|---|
| 1C–3C | 0.5–2.5 | 16–18 | 0–1 year |
| 4C–7C | 3–6 | 19–23 | 1–3 years |
| 8C–13C | 7–12 | 24–31 | 3–7 years |
| 1Y–6Y | 13–5 | 32–38 | 7–12 years |

---

## Sizing Tips

### General Tips
- **Read product reviews:** Customers often comment on whether items run large, small, or true to size
- **Check the product page:** Many items include specific sizing recommendations from the brand
- **When in between sizes:** Order the larger size for a more comfortable fit
- **Different brands may vary:** Even within the same size label, fit can differ between brands

### Category-Specific Tips
- **Jeans:** Denim may stretch slightly after a few wears. If you prefer a snug fit, consider sizing down
- **Athletic/activewear:** Designed for movement — order your usual size or size up for a relaxed fit
- **Outerwear/jackets:** Consider layering. If you plan to wear heavy layers underneath, size up
- **Shoes:** Always try shoes on in the afternoon when your feet are slightly larger from activity
- **Furniture:** Always verify dimensions (length × width × height) against your room measurements before ordering

### Free Returns on Sizing Issues
- Items returned due to sizing are eligible for free returns within the standard return window
- Select "Size too small" or "Size too large" as the return reason
- No return shipping fee applies for sizing-related returns
- We recommend ordering two sizes and returning the one that doesn't fit

---

## Product Condition Guide

| Condition | Description | Warranty | Returns |
|---|---|---|---|
| **New** | Factory sealed, never opened | Full manufacturer warranty | Standard return policy |
| **Certified Refurbished** | Professionally restored to like-new condition, tested and inspected | 90-day NovaMart warranty | 30-day return window |
| **Open Box** | Returned item in original packaging, inspected and verified complete | 90-day NovaMart warranty | 30-day return window |
| **Used — Like New** | Minimal signs of use, fully functional, all accessories included | 30-day NovaMart warranty | 15-day return window |
| **Used — Good** | Minor cosmetic wear, fully functional | 30-day NovaMart warranty | 15-day return window |

### Certified Refurbished Promise
- Every Certified Refurbished product is tested across 65+ checkpoints
- Battery health must be at least 85% for electronics
- All accessories (charger, cable, manual) included — original or NovaMart-certified equivalent
- Products are cleaned, sanitized, and repackaged in NovaMart Certified packaging
- If any issue arises within 90 days, we'll replace the product or issue a full refund

---

## Contact Product Support

- **Sizing help:** sizing@novamart.com
- **Product questions:** products@novamart.com
- **Phone:** 1-800-NOVA-MART (1-800-668-2627), option 2 for product inquiries
- **Hours:** Monday–Friday, 8:00 AM – 8:00 PM EST; Saturday, 9:00 AM – 5:00 PM EST
- **Live Chat:** Available at novamart.com during business hours — our stylists can help you find the right size
