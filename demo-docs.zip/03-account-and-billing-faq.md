# Account & Billing FAQ

**Last Updated:** January 2025  
**Company:** NovaMart — Your Premium Online Marketplace

---

## Account Management

### Creating an Account
- Visit novamart.com/register or click "Sign Up" in the top-right corner
- You can register with your email address or use social login (Google, Apple, Facebook)
- You must be 18 years or older to create an account
- One account per email address is permitted

### Logging In
- Go to novamart.com/login
- Enter your registered email and password
- Enable "Remember Me" for faster access on trusted devices
- Two-Factor Authentication (2FA) is available via authenticator app or SMS

### Resetting Your Password
1. Click "Forgot Password" on the login page
2. Enter your registered email address
3. Check your inbox for a password reset link (valid for 1 hour)
4. Click the link and create a new password
5. Your new password must be at least 8 characters and include uppercase, lowercase, number, and special character
6. If you don't receive the email, check your spam/junk folder or contact support

### Updating Your Profile
- Log in → click your avatar → "Account Settings"
- You can update: name, email, phone number, default shipping address, communication preferences
- Email changes require verification via a confirmation link sent to both old and new email addresses
- Phone number changes may require SMS verification

### Deleting Your Account
- Contact support at support@novamart.com or call 1-800-NOVA-MART
- Account deletion is permanent and cannot be undone
- Any remaining store credits or NovaMart Rewards points will be forfeited
- Unused gift card balances can be transferred to another account or used before deletion — contact support
- Order history is retained for 7 years after deletion for tax and legal compliance
- Processing time: 5–7 business days

---

## Payment Methods

### Accepted Payment Methods
- **Credit Cards:** Visa, Mastercard, American Express, Discover
- **Debit Cards:** Any card with Visa or Mastercard logo
- **PayPal:** Standard PayPal and PayPal Credit
- **Apple Pay:** Available on Safari and Apple devices
- **Google Pay:** Available on Chrome and Android devices
- **Buy Now, Pay Later:** Affirm (4 interest-free payments), Klarna (Pay in 4)
- **NovaMart Gift Cards:** Physical and digital gift cards
- **Store Credit:** Applied automatically at checkout if available

### Managing Payment Methods
- Log in → "Account Settings" → "Payment Methods"
- You can save up to 5 payment methods
- Set a default payment method for faster checkout
- Remove expired or unused cards at any time
- All payment data is encrypted and PCI DSS Level 1 compliant

### Payment Security
- All transactions are encrypted with 256-bit SSL/TLS
- We never store your full card number — only the last 4 digits are displayed
- 3D Secure (Verified by Visa, Mastercard SecureCode) is supported
- Suspicious activity triggers automatic fraud detection and may temporarily hold your order
- If your payment is declined, verify your card details and contact your bank

---

## Billing & Charges

### Order Total Breakdown
Your order total includes:
- **Subtotal:** Sum of all item prices
- **Shipping:** Based on selected shipping method (free over $50 for Standard)
- **Tax:** Sales tax calculated based on your shipping address
- **Discounts:** Promo codes, coupons, and NovaMart Rewards applied
- **Final Total:** Amount charged to your payment method

### Pre-Authorization Holds
- When you place an order, a temporary hold (pre-authorization) is placed on your payment method
- This is NOT a charge — it's a hold to verify funds
- The actual charge occurs when your order ships
- If your order is cancelled, the hold is released within 3–5 business days (varies by bank)

### Multiple Charges
If you see multiple charges for one order, it may be because:
- Your order was shipped in multiple packages (each shipment is charged separately)
- A pre-authorization hold appears alongside the actual charge (the hold will drop off in 3–5 business days)
- You modified your order after placement

### Invoices & Receipts
- Invoices are emailed automatically when your order ships
- You can download invoices from "My Orders" → click the order → "Download Invoice"
- Business customers can request VAT/tax invoices by contacting support
- Invoices include: order number, item details, prices, taxes, shipping costs, payment method (last 4 digits)

---

## NovaMart Rewards Program

### How It Works
- Earn 1 point for every $1 spent
- 100 points = $5 discount on your next order
- Points are earned on the item subtotal (excluding tax, shipping, and gift card purchases)
- Points are credited 30 days after delivery (to allow for returns)

### Membership Tiers
| Tier | Annual Spend | Benefits |
|---|---|---|
| **Bronze** | $0 – $499 | 1x points, birthday bonus |
| **Silver** | $500 – $1,499 | 1.5x points, free Standard shipping, early access to sales |
| **Gold** | $1,500 – $4,999 | 2x points, free Express shipping, priority support |
| **Platinum** | $5,000+ | 3x points, free Overnight shipping, dedicated account manager |

### Redeeming Points
- Points can be applied at checkout under "NovaMart Rewards"
- Minimum redemption: 50 points ($2.50 discount)
- Points can be combined with promo codes unless specifically excluded
- Points expire 12 months after the date they were earned
- Points are non-transferable and have no cash value

### Premium Membership
- **Cost:** $99/year or $9.99/month
- **Benefits:** Free Express shipping on all orders, 2x bonus points, early access to new products, extended 60-day return window, exclusive member-only pricing
- **Cancellation:** Cancel anytime from Account Settings; remaining month/year access is honored

---

## Promotions & Discounts

### Applying Promo Codes
1. Add items to your cart
2. Proceed to checkout
3. Enter your promo code in the "Discount Code" field
4. Click "Apply"
5. The discount will be reflected in your order total

### Promo Code Rules
- Only one promo code can be used per order
- Promo codes cannot be combined with other offers unless stated otherwise
- Promo codes have expiration dates — check the terms
- Some promo codes have minimum spend requirements
- Promo codes cannot be applied retroactively to placed orders

### Price Matching
- NovaMart offers price matching within 7 days of purchase
- The item must be identical (same brand, model, color, size)
- The competitor must be an authorized retailer
- Online competitor prices must be publicly available (no membership-only prices)
- Contact support with a link to the competitor's product page

---

## Contact Information

- **Email:** support@novamart.com
- **Phone:** 1-800-NOVA-MART (1-800-668-2627)
- **Hours:** Monday–Friday, 8:00 AM – 8:00 PM EST; Saturday, 9:00 AM – 5:00 PM EST
- **Live Chat:** Available at novamart.com during business hours
- **Help Center:** novamart.com/help
