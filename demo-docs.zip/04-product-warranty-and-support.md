# Product Warranty & Technical Support

**Last Updated:** January 2025  
**Company:** NovaMart — Your Premium Online Marketplace

---

## Standard Warranty Coverage

All products sold by NovaMart come with a manufacturer's warranty at no additional cost. Warranty begins from the date of delivery as confirmed by tracking.

| Product Category | Warranty Period | Coverage |
|---|---|---|
| Electronics (laptops, phones, tablets) | 1 year | Manufacturing defects, hardware failure |
| Home Appliances (kitchen, cleaning) | 2 years | Manufacturing defects, motor failure |
| Furniture | 1 year | Structural defects, material failures |
| Clothing & Accessories | 90 days | Stitching defects, material flaws |
| Sporting Goods | 6 months | Manufacturing defects |
| Audio Equipment (headphones, speakers) | 1 year | Driver failure, connectivity defects |
| Smart Home Devices | 1 year | Hardware failure, sensor defects |
| Outdoor & Garden | 6 months | Structural defects, weather-related material failure |

### What Standard Warranty Covers
- Manufacturing defects present at time of purchase
- Hardware component failure under normal use
- Electrical and mechanical malfunctions not caused by user
- Battery failure or capacity degradation below 80% within warranty period

### What Standard Warranty Does NOT Cover
- Damage from misuse, abuse, or unauthorized modifications
- Cosmetic damage (scratches, dents) that does not affect functionality
- Damage from exposure to liquids (unless device is rated water-resistant)
- Normal wear and tear (battery aging, rubber degradation, fabric pilling)
- Software issues, viruses, data loss, or third-party accessory damage
- Loss or theft
- Items purchased from unauthorized sellers outside the NovaMart platform (NovaMart Fulfilled sellers are authorized and covered)

---

## NovaCare Extended Warranty Plans

Extend your protection beyond the standard warranty with NovaCare. Plans can be purchased at checkout or within 30 days of delivery from "My Orders" → "Add NovaCare."

| Plan | Extra Coverage | Price | Eligible Items |
|---|---|---|---|
| **NovaCare Basic** | +1 year | $29.99 | Items under $200 |
| **NovaCare Plus** | +2 years | $49.99 | Items under $500 |
| **NovaCare Premium** | +3 years + accidental damage | $79.99 | Items under $1,000 |
| **NovaCare Ultra** | +3 years + accidental damage + theft | $129.99 | Items under $2,000 |

### What NovaCare Covers (all plans)
- Manufacturing defects after standard warranty expires
- Electrical and mechanical failures
- Battery degradation below 50% capacity
- Power surge damage
- Free shipping for all warranty repairs/replacements

### Additional Coverage by Plan
- **NovaCare Premium & Ultra:** Accidental damage including drops, spills, and cracked screens (up to 2 claims per year)
- **NovaCare Ultra only:** Theft protection (police report required, one claim per plan term)

### What NovaCare Does NOT Cover
- Cosmetic damage that doesn't affect functionality
- Damage from unauthorized repairs or modifications
- Loss (except NovaCare Ultra with police report)
- Software issues, viruses, or data loss
- Normal wear and tear
- Pre-existing damage not reported within 14 days of delivery
- Accessories not covered under the original product's plan

### NovaCare Claim Process
1. Log in to novamart.com → "My Orders" → select the product
2. Click "File NovaCare Claim"
3. Describe the issue and upload photos/videos
4. Receive a claim decision within 2 business days
5. If approved:
   - **Repair:** Prepaid shipping label provided; device returned within 7–14 business days
   - **Replacement:** Identical or equivalent product shipped via Express (2–3 days)
   - **Refund:** Original purchase price minus depreciation (only if no replacement is available)

---

## Filing a Standard Warranty Claim

### Before You File
1. **Verify warranty status:** Check "My Orders" → click the product → "Warranty Status"
2. **Try troubleshooting:** See our guides below — many issues can be resolved without a claim
3. **Gather information:** Order number, product serial number, description and photos/videos of the defect

### How to File
- **Online (fastest):** novamart.com/warranty-claim — upload your claim and track progress in real-time
- **Email:** warranty@novamart.com — include order number and photos in your first email
- **Phone:** 1-800-NOVA-MART (1-800-668-2627), option 3

### Claim Resolution
| Resolution Type | Timeline | When Used |
|---|---|---|
| **Repair** | 7–14 business days | Fixable defects (electronics, appliances) |
| **Replacement** | 2–5 business days | Unrepairable defects, same or equivalent model |
| **Refund** | 3–10 business days | Replacement unavailable, discontinued products |
| **Parts replacement** | 3–7 business days | Missing/broken parts (furniture, accessories) |

### What Happens to Your Defective Item
- **Repair claims:** We ship a prepaid box; you return the item for repair
- **Replacement claims:** You may be asked to return the defective item within 14 days using a prepaid label
- **Low-value items (under $25):** You may keep the defective item — no return required
- **Hazardous items (batteries, electronics with swelling):** Special return instructions will be provided

---

## Troubleshooting Guides

### Electronics: Device Won't Turn On
1. Charge for at least 30 minutes using the original charger and cable
2. Try a different wall outlet (avoid USB ports on computers for initial charge)
3. Hard reset: hold the power button for 15–20 seconds, release, then press again
4. If the device has a removable battery, remove it for 30 seconds, reinsert, and try again
5. Try a different charging cable — cables degrade over time
6. Check for LED indicators: a blinking light may indicate a specific error (check novamart.com/manuals)
7. If none of the above works, file a warranty claim

### Electronics: Slow Performance
1. Close all unused applications and browser tabs
2. Restart the device completely (full shutdown, not just sleep)
3. Check for and install pending software/firmware updates
4. Clear browser cache and temporary files
5. Free up storage space — aim for at least 15% free space
6. Disable background applications and startup programs
7. Run a malware/virus scan using trusted security software
8. Factory reset as a last resort — **back up all data first**
9. If performance issues persist after factory reset, contact support

### Electronics: Wi-Fi & Connectivity Issues
1. Restart your device and your router/modem
2. Forget the Wi-Fi network and reconnect with the password
3. Move closer to the router to rule out signal strength issues
4. Check if other devices can connect — if not, the issue is with your router
5. Update the device's network drivers or firmware
6. Reset network settings on the device (Settings → Network → Reset)
7. Try connecting to a different Wi-Fi network to isolate the issue
8. If Bluetooth: unpair, restart, and re-pair the device

### Electronics: Battery Draining Quickly
1. Check battery health in device settings (Settings → Battery → Battery Health)
2. Reduce screen brightness and enable auto-brightness
3. Turn off unused features: Bluetooth, Wi-Fi, GPS, NFC when not in use
4. Disable background app refresh for non-essential apps
5. Update all apps and the operating system
6. Avoid extreme temperatures — batteries degrade faster in heat
7. If battery health is below 80%, contact support for a warranty battery replacement

### Home Appliances: Not Working
1. Verify the power outlet works (test with another device)
2. Check that the appliance is properly plugged in and any power switch is ON
3. Look for a reset button (usually a small button on the back or bottom)
4. Check the circuit breaker — the appliance may have tripped it
5. Review novamart.com/manuals for model-specific error codes and solutions
6. For motor-driven appliances: check for blockages or overheating (let it cool for 30 minutes)
7. For appliances with water connections: check that valves are open and hoses are not kinked
8. Contact support if the issue persists — include the model number and error code (if any)

### Home Appliances: Unusual Noises
1. Check that the appliance is on a level surface
2. Look for loose parts or packaging material left inside
3. Verify nothing is blocking moving parts (fan, motor, blades)
4. Slight humming is normal for motor-driven appliances
5. Grinding, clicking, or rattling noises may indicate a hardware issue — contact support

### Furniture: Assembly Issues
1. Download the latest assembly manual from novamart.com/manuals (enter model number)
2. Verify all parts against the included checklist — compare part numbers
3. Watch the video assembly guide on the NovaMart YouTube channel
4. Use the recommended tools — do not over-tighten screws (can strip holes)
5. Missing or damaged parts: contact support for free replacement parts (shipped within 3 business days)
6. If you need professional assembly, NovaMart partners with TaskRabbit — book at novamart.com/assembly

### Furniture: Structural Issues After Assembly
1. Check that all screws and bolts are properly tightened
2. Ensure the furniture is on a level surface
3. Verify weight limits have not been exceeded (check product specs)
4. Take photos of any cracks, splits, or bowing
5. Contact support — structural defects within warranty are covered for repair or replacement

### Smart Home Devices: Setup Issues
1. Ensure the device is connected to a 2.4GHz Wi-Fi network (most smart devices do not support 5GHz)
2. Download the latest version of the companion app from the App Store or Google Play
3. Enable Bluetooth on your phone during initial setup
4. Place the device within 15 feet of your router during setup
5. Factory reset the device and start the setup process over
6. Check compatibility requirements on the product page (some devices require a hub)

---

## Software & App Support

### NovaMart Mobile App
- **Download:** Available on iOS (App Store) and Android (Google Play)
- **Requirements:** iOS 15+ or Android 10+
- **Features:** Order tracking, returns, NovaMart Rewards, NovaCare claims, live chat support
- **Issues:** If the app crashes or freezes, try clearing the cache (Settings → Apps → NovaMart → Clear Cache) and update to the latest version

### Smart Home App (NovaMart Home)
- **Download:** iOS and Android — search "NovaMart Home"
- **Compatible devices:** NovaMart smart plugs, bulbs, cameras, thermostats, doorbells
- **Setup:** Follow the in-app pairing wizard (requires Bluetooth enabled)
- **Troubleshooting:** If devices go offline, check your Wi-Fi and power cycle the device

---

## Repair Services

### In-Warranty Repair
- Free of charge for covered defects
- Prepaid shipping provided — pack the item securely
- Typical turnaround: 7–14 business days (includes shipping both ways)
- Loaner devices available for NovaCare Premium and Ultra customers (select products)

### Out-of-Warranty Repair
- Available for electronics and appliances past their warranty period
- Diagnostic fee: $29.99 (waived if you proceed with the repair)
- Repair estimates provided before any work begins — no surprises
- Common repairs: screen replacement ($89–$199), battery replacement ($39–$79), motor replacement ($49–$129)
- Repaired items receive a 90-day repair warranty
- Replacement items inherit the remaining original warranty or 90 days, whichever is longer

---

## Contact Technical Support

- **Email:** warranty@novamart.com (warranty claims), techsupport@novamart.com (troubleshooting)
- **Phone:** 1-800-NOVA-MART (1-800-668-2627), option 3 for warranty, option 5 for tech support
- **Hours:** Monday–Friday, 8:00 AM – 8:00 PM EST; Saturday, 9:00 AM – 5:00 PM EST
- **Live Chat:** Available at novamart.com during business hours
- **Video Support:** Screen-sharing troubleshooting available for NovaCare customers — schedule at novamart.com/video-support
- **Manuals & Guides:** novamart.com/manuals
- **YouTube:** youtube.com/@NovaMart — assembly guides, setup tutorials, troubleshooting videos
